/***********************************************************************
*   LOCATION FUNCTION
*   PM Sep 2017
************************************************************************/

function setImagingLocation(i) {
	switch(i) {
			default:
			address="";
			break;
		case "EKRH":
			address = 'Cranbrook \nFax (250) 417-3548';
			break;
		case "KGH":
			address = 'Kelowna \nFax (250) 862-4017';
			break;
		case "KBRH":
			address = "Trail \nFax (250) 364-3435";
			break;
		case "PRG":
			address = 'Penticton \nFax (778) 622-1828';
			break;
		case "RIH":
			address = 'Kamloops \nFax (250) 314-2326';
			break;
			case "VJH":
			address = 'Vernon \nFax (250) 558-2103';
			break;
	}

	document.FormName.Location.value = address;
}