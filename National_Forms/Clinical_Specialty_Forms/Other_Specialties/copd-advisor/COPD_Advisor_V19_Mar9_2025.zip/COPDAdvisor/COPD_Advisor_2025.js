function Instructions0() {
	document.FormName.Instructions.value = "What is COPD?\nCOPD is a common, preventable and treatable disease that is characterized by persistent respiratory symptoms and airflow limitation usually caused by significant exposure to noxious particles or gases. It is notable for periods of acute worsening of respiratory symptoms, called exacerbations. There are often increasing frequency and severity of exacerbations.  There are often co-existent diseases that worsen outcomes: cardiovascular disease, cachexia, metabolic syndrome, osteoporosis, depression, anxiety, lung cancer, GERD, sleep apnea). \n\nThe main risk factor for COPD is TOBACCO smoking. Other types of tobacco, (e.g. pipe, cigar, water pipe) and marijuana are also risk factors for COPD. Other environmental exposures such as biomass fuel exposure and air pollution may contribute. \n\nSometimes it is associated with a genetic disorder, alpha-1 antitrypsin deficiency - a blood test may be done to screen for this.";
}

function Instructions1() {
	document.FormName.Instructions.value = "Who should be targeted for screening spirometry? (COPD can only be diagnosed with lung testing - spirometry)\nAdults over age 40 who answer yes to any questions below: \n1. Have you smoked cigarettes for more than 10 years? (>10 pack-years)\n2. Do you cough regularly? (dry cough)\n3. Do you cough up phlegm regularly? (wet cough)\n4. Do even simple chores make you short of breath (dyspnea)? \n5. Do you wheeze when you exert yourself? Or wheeze at night? \n6. Do you get frequent colds that persist longer than those of other people? \n7. Have you been exposed to occupational dusts and chemicals? \n8. Have you been exposed to smoke from home cooking and heating fuels?";
}

function Instructions2() {
	document.FormName.Instructions.value = "Reduce SYMPTOMS: \n-Relieve symptoms (cough, dyspnea) \n-Improve exercise tolerance \n-Improve health status \n\n...and... \n\nReduce RISK: \n-Prevent disease progression \n-Prevent and treat exacerbations \n-Reduce mortality ";
}

function Instructions3() {
	document.FormName.Instructions.value = "Non-Pharmacological therapy \n\nSmoking CESSATION is paramount! \n\nAll COPD patients should be encouraged to remain active. Stable, symptomatic patients should be referred to a comprehensive pulmonary rehabilitation program, which includes exercise training and self-management education. Benefits include reduced dyspnea, improved exercise tolerance and quality of life which, in turn reduces the burden on the healthcare system.  Unfortunately, pulmonary rehabilitation does not reduce mortality. \n\nFlu and Pneumococcal vaccination are recommended.";
}

function Instructions4() {
	document.FormName.Instructions.value = "Pharmacologic therapy may reduce symptoms, and the risk and severity of exacerbations, as well as improve health status and exercise tolerance. \n\nAs most drugs are inhaled, proper INHALER TECHNIQUE is essential. Inhaled agents are preferred over oral meds. \n\nIn general LABAs and LAMAs are preferred over short-acting agents. \n\nLong-term monotherapy with ICS is not recommended.";
}

function Instructions5() {
	document.FormName.Instructions.value = "Long-term oxygen therapy can improve survival and function in appropriately chosen, stable COPD patients with chronic hypoxemia. \n\nConsider oxygen if PaO2 < 55 mm Hg or Sa02 <88% or PaO2 55-60 mm Hg with Rt heart failure or erythrocytosis. \n\nSupplemental oxygen provided to keep SaO2 >= 90%. None of the currently available bronchodilators have been effective in improving longevity, only oxygen does this.  Puffers are for QOL!";
}

function Instructions6() {
	document.FormName.Instructions.value = "End of Life Care \nCOPD is a progressive, disabling condition that may lead to respiratory failure and death.\nPhysicians have a responsibility to discuss end of life issues and to provide support to COPD patients and their caregivers.\nProfile of a COPD patient at risk of death: very severe airflow obstruction (FEV1 < 35% predicted), poor functional status (MRC 4-5), poor nutritional status (BMI < 19), increasing severity and frequency of exacerbations, older age, pulmonary hypertension, and concurrent heart failure.";
}
