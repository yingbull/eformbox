		function himConsult() {
				document.getElementById('PickUpStPauls_No').value = 'X';
				document.getElementById('PickUp_Location').value = 'New West STI Clinic';
				document.getElementById('clinic_addressLineFull').value = 'C/O New Westminster STI Clinic \nSuite 218 - 610 Sixth St \nNew Westminster, BC, V3L 3C2';
				document.getElementById('clinic_phone').value = '604-777-6740';
				document.getElementById('clinic_fax').value = '604-525-0878';
				document.getElementById('subject').value = 'STI Consult';
			}