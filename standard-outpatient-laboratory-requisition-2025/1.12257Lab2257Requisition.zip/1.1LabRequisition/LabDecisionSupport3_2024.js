function autoLabReqPop() {
	// scrollPage();
	insertData();
}

function insertData() {
	// check smoking box and Family History on startup and check box. Need to do this before the rest
	// removed to stop push and pull to/from SKST measurement - inactivates Framingham calculator
	if ((document.getElementById('smoker').value === 'yes') || (document.getElementById('smoker').value === 'Yes')) {
		$("#SmokingStatus").attr('checked', true);
	}
	medicalConditions();
	medicalIssues();
	decisionSupport();
	PopValues();
}

//This is where the lab arrays are placed with all the different options
function PopValues() { 
    const labsConfig = [
	    {
            name: " Hb",    //This is the title on hover and the name for the ZAccumulativeView
            loincs: "718-7",
            displayId: "HematologyProfile",  //This is the id of the checkbox
			labname: "Yes", //This attaches the name to the output
            thresholds: [{ limit: 115, color: "blue", isLowerLimit: true }, { limit: 160, color: "#FF0000", isLowerLimit: false }],
			yellowConditions: [{ conditionId: "CKDC", monthsThreshold: 11 },{ conditionId: "CHFC", monthsThreshold: 11 },{ conditionId: "ValproC", monthsThreshold: 11 },{ conditionId: "MetfC", monthsThreshold: 11 },{ conditionId: "PhenyC", monthsThreshold: 11 },{ conditionId: "LithC", monthsThreshold: 5 },{ conditionId: "MethoC", monthsThreshold: 2 }],
            position: { left: 85, top: 372 } 
        },
        {
            name: "W",
			//loincs: ["6690-2","12227-5"],
            loincs: ["12227-5","6690-2"],
            displayId: "WCC",
			labname: "Yes",
            thresholds: [{ limit: 4, color: "#003EFF", isLowerLimit: true }, { limit: 11, color: "#FF0000", isLowerLimit: false }],  
            date: "None", // Skip monthsAgo for this lab
			position: { left: 125, top: 372 }
        },
		{
            name: "P",
            loincs: "777-3", 
            displayId: "PLT",
			labname: "Yes",
            thresholds: [{ limit: 150, color: "#003EFF", isLowerLimit: true }, { limit: 400, color: "#FF0000", isLowerLimit: false }],  
            date: "None",
			position: { left: 160, top: 372 }
        },
		{
            name: "INR",
            loincs: "6301-6", 
            displayId: "INR",
            thresholds: [{ limit: 2, color: "#003EFF", isLowerLimit: true }, { limit: 3, color: "#FF0000", isLowerLimit: false }],  
			position: { left: 130, top: 390 }
        },
		{
            name: "FER",
			loincs: ["2276-4", "35209-6", "20567-4"], 
            displayId: "FER",
            thresholds: [{ limit: 15, color: "#003EFF", isLowerLimit: true }, { limit: 250, color: "#FF0000", isLowerLimit: false }],  
			position: { left: 130, top: 406 }
        },
        {
            name: "eGFR",
            loincs: ["33914-3", "62238-1"],
            displayId: "CreatinineGFR",
            thresholds: [{ limit: 60, color: "#003EFF", isLowerLimit: true }],
            yellowConditions: [{ conditionId: "HBPC", monthsThreshold: 11 },{ conditionId: "DMC", monthsThreshold: 11 },{ conditionId: "DigC", monthsThreshold: 11 },{ conditionId: "MetfC", monthsThreshold: 11 },{ conditionId: "NOACC", monthsThreshold: 11 },{ conditionId: "LithC", monthsThreshold: 11 },{ conditionId: "CHFC", monthsThreshold: 5 },{ conditionId: "CKDC", monthsThreshold: 5 },{ conditionId: "SpiroC", monthsThreshold: 2 },{ conditionId: "MethoC", monthsThreshold: 1 }],			
            position: { left: 770, top: 728 } 
        },
		{
            name: "CA",
            loincs: ["2000-8"],
            displayId: "Calcium",
            thresholds: [ { limit: 2.1, color: "#003EFF", isLowerLimit: true },{ limit: 2.6, color: "#FF0000", isLowerLimit: false }],  			
            position: { left: 770, top: 741 }
        },
		{
            name: "CK",
            loincs: ["2157-6"],
            displayId: "CK",
            thresholds: [ { limit: 140, color: "#FF0000", isLowerLimit: false }],  			
            position: { left: 770, top: 756 }
        },
		{
            name: "PSA",
            loincs: ["2857-1"],
            displayId: "PSA",
            thresholds: [ { limit: 4.5, color: "#FF0000", isLowerLimit: false }],  			
            position: { left: 770, top: 781 }
        },
		{
            name: "BHCG",
            loincs: ["21198-7"],
            displayId: "BHCG",
            position: { left: 770, top: 822 }
        },
		
		{
            name: "Na",
			loincs: ["2947-0","2951-2"],
            displayId: "Sodium",
            thresholds: [{ limit: 135, color: "#003EFF", isLowerLimit: true }, { limit: 145, color: "#FF0000", isLowerLimit: false }],  
            yellowConditions: [{ conditionId: "HBPC", monthsThreshold: 11 },{ conditionId: "DMC", monthsThreshold: 11 },{ conditionId: "DigC", monthsThreshold: 11 },{ conditionId: "LithC", monthsThreshold: 5 },{ conditionId: "CHFC", monthsThreshold: 5 },{ conditionId: "CKDC", monthsThreshold: 5 },{ conditionId: "SpiroC", monthsThreshold: 2 }],			
            position: { left: 588, top: 728 }
        },
		{
            name: "K",
            loincs: ["2823-3"],
            displayId: "Potassium",
            thresholds: [{ limit: 3.5, color: "#003EFF", isLowerLimit: true }, { limit: 5, color: "#FF0000", isLowerLimit: false }],  
			yellowConditions: [{ conditionId: "HBPC", monthsThreshold: 11 },{ conditionId: "DMC", monthsThreshold: 11 },{ conditionId: "DigC", monthsThreshold: 11 },{ conditionId: "LithC", monthsThreshold: 5 },{ conditionId: "CHFC", monthsThreshold: 5 },{ conditionId: "CKDC", monthsThreshold: 5 },{ conditionId: "SpiroC", monthsThreshold: 2 }],			
            position: { left: 588, top: 741 }
        },
		{
            name: "ALB",
            loincs: ["1751-7"],
            displayId: "Albumin",
            thresholds: [{ limit: 35, color: "#003EFF", isLowerLimit: true }, { limit: 50, color: "#FF0000", isLowerLimit: false }],  
			yellowConditions: [{ conditionId: "CHFC", monthsThreshold: 1000 }],			
            position: { left: 588, top: 753 }
        },
	    {
            name: "ALP",
            loincs: ["6768-6"],
            displayId: "ALP",
            thresholds: [{ limit: 35, color: "#003EFF", isLowerLimit: true }, { limit: 105, color: "#FF0000", isLowerLimit: false }],  			
            position: { left: 588, top: 765 }
        },
		{
           name: "ALT",
            loincs: ["1742-6"],
            displayId: "ALT",
            thresholds: [ { limit: 35, color: "#FF0000", isLowerLimit: false }],  			
            yellowConditions: [{ conditionId: "CHFC", monthsThreshold: 1000 },{ conditionId: "PhenyC", monthsThreshold: 11 },{ conditionId: "ValproC", monthsThreshold: 11 },{ conditionId: "AmioC", monthsThreshold: 5 },{ conditionId: "MethoC", monthsThreshold: 2 },{ conditionId: "AccutC", monthsThreshold: 2 }],
            position: { left: 588, top: 777 }
        },
		{
            name: "B12",
            loincs: ["14685-2"],
            displayId: "B12",
            thresholds: [ { limit: 135, color: "#003EFF", isLowerLimit: true },{ limit: 655, color: "#FF0000", isLowerLimit: false }],  			
            position: { left: 588, top: 790 }
        },
		{
            name: "BILI",
            loincs: ["14631-6"],
            displayId: "Bilirubin",
            thresholds: [ { limit: 17, color: "#FF0000", isLowerLimit: false }],  			
            position: { left: 588, top: 802 }
        },
		{
            name: "GGT",
            loincs: ["2324-2"],
            displayId: "GGT",
            thresholds: [ { limit: 30, color: "#FF0000", isLowerLimit: false }],  			
            position: { left: 588, top: 813 }
        },
		{
            name: "PROT",
            loincs: ["2885-2"],
            displayId: "TotalProtein",
            thresholds: [ { limit: 50, color: "#003EFF", isLowerLimit: true },{ limit: 80, color: "#FF0000", isLowerLimit: false }],  			
            position: { left: 588, top: 826 }
        },
		{
            name: "FBS",
            loincs: ["14771-0"],
            displayId: "GlucoseFasting",
            thresholds: [ { limit: 3.6, color: "#003EFF", isLowerLimit: true },{ limit: 5.9, color: "#FF0000", isLowerLimit: false }],  			
            yellowConditions: [{ conditionId: "CHFC", monthsThreshold: 1000 }],
            position: { left: 770, top: 375 }
        },
		{
            name: "RBS",
            loincs: ["14749-6"],
            displayId: "GlucoseRandom",
            thresholds: [ { limit: 3.6, color: "#003EFF", isLowerLimit: true },{ limit: 11.1, color: "#FF0000", isLowerLimit: false }],  			
            position: { left: 770, top: 388 }
        },
		{
            name: "A1C",
            loincs: "4548-4",
            displayId: "A1c",
            thresholds: [{ limit: 4, color: "#003EFF", isLowerLimit: true }, { limit: 6.5, color: "#FF0000", isLowerLimit: false }],
            yellowConditions: [{ conditionId: "CKDC", monthsThreshold: 11 },{ conditionId: "HBPC", monthsThreshold: 11 },{ conditionId: "AAPsyC", monthsThreshold: 11 },{ conditionId: "DMC", monthsThreshold: 5 }],
            position: { left: 770, top: 457 }
        },
		{
            name: "ACR",
            loincs: ["9318-7", "32294-1"],
            displayId: "ACR",
			thresholds: [ { limit: 2.0, color: "#FF0000", isLowerLimit: false }],
			yellowConditions: [{ conditionId: "DMC", monthsThreshold: 11 },{ conditionId: "CKDC", monthsThreshold: 11 }],
            position: { left: 770, top: 471 }
        },
		{
            name: " TC",
            loincs: ["14647-2"],
            displayId: "TotalCholesterol",
			labname: "Yes",
            thresholds: [ { limit: 2, color: "#003EFF", isLowerLimit: true },{ limit: 5.2, color: "#FF0000", isLowerLimit: false }],  			
            yellowConditions: [{ conditionId: "CKDC", monthsThreshold: 23 },{ conditionId: "DMC", monthsThreshold: 11 },{ conditionId: "HBPC", monthsThreshold: 60 },{ conditionId: "AAPsyC", monthsThreshold: 23 }],
            checkStatin: function (displayId) {if (Statin !== 0) {$(`#${displayId}`).removeClass("yellow");}},
			position: { left: 604, top: 487 }
        },
		{
            name: "LDL",
            loincs: ["39469-2", "22748-8"],
            displayId: "LDL",
			labname: "Yes",
            thresholds: [{ limit: 1.5, color: "#003EFF", isLowerLimit: true }, { limit: 3.4, color: "#FF0000", isLowerLimit: false }],  
            date: "None",
			position: { left: 649, top: 487 }
        },
		{
            name: "HDL",
            loincs: ["14646-4"],
            displayId: "HDL",
			labname: "Yes",
            thresholds: [{ limit: 0.9, color: "#003EFF", isLowerLimit: true }],  
            date: "None",
			position: { left: 694, top: 487 }
        },
		{
            name: "R",
            loincs: ["32309-7", "9322-9"],
            displayId: "TCHD",
			labname: "Yes",
            thresholds: [{ limit: 4.9, color: "#FF0000", isLowerLimit: false }],  
            date: "None",
			position: { left: 730, top: 487 }
        },
		{
            name: "TG",
            loincs: ["14927-8"],
            displayId: "TRIG",
			labname: "Yes",
            thresholds: [{ limit: 2.3, color: "#FF0000", isLowerLimit: false }],  
            date: "None",
			position: { left: 770, top: 487 }
        },
		
	    {
            name: "URIC",
            loincs: ["14933-6"],
            displayId: "URATE",
            thresholds: [ { limit: 140, color: "#003EFF", isLowerLimit: true },{ limit: 360, color: "#FF0000", isLowerLimit: false }],  			
            position: { left: 910, top: 940 }
        },
		{
            name: "AST",
            loincs: ["1920-8"],
            displayId: "AST",
            thresholds: [ { limit: 35, color: "#FF0000", isLowerLimit: false }],  			
            position: { left: 1000, top: 940 }
        },
		{
            name: "BNP",    
			loincs: ["30934-4","33762-6"],
            displayId: "BNP",
            thresholds: [ { limit: 100, color: "#FF0000", isLowerLimit: false }],  			
            position: { left: 1095, top: 940 }
        },
		{
            name: "Troponin",
            loincs: ["89579-7", "10839-9"],
            displayId: "Troponin",
            thresholds: [ { limit: 11, color: "#FF0000", isLowerLimit: false }],  			
            position: { left: 1190, top: 940 }
        },
		
		{
            name: "CRP",
            loincs: ["30522-7", "1988-5"],
            displayId: "CRP",
            thresholds: [{ limit: 7.5 , color: "#FF0000", isLowerLimit: false }],  			
            position: { left: 910, top: 970 }
        },
		{
            name: "ESR",
            loincs: ["4537-7"],
            displayId: "ESR",
            thresholds: [ { limit: 35, color: "#FF0000", isLowerLimit: false }],  			
            position: { left: 1000, top: 970 }
        },
		{
            name: "VitD",
            loincs: ["68438-1"],
            displayId: "VitD",
            thresholds: [ { limit: 70, color: "#003EFF", isLowerLimit: true }],  			
            position: {  left: 1095, top: 970 }
        },

		{
            name: "RF",
            loincs: ["11572-5", "15205-8"],
            displayId: "RF",
            thresholds: [ { limit: 30, color: "#FF0000", isLowerLimit: false }],  			
            position: { left: 1190, top: 970 }
        },
		
		{
            name: "TTG",
            loincs: ["31017-7"],
            displayId: "TTG",
            thresholds: [{ limit: 20, color: "#FF0000", isLowerLimit: false }],  			
            position: { left: 910, top: 1000 }
        },
		{
            name: "Fecal_Calprotectin",
            loincs: ["38445-3"],
            displayId: "FCAL",
            thresholds: [ { limit: 50, color: "#FF0000", isLowerLimit: false }],  			
            position: { left: 1000, top: 1000 }
        },

		{
            name: "Thyroglobulin",
            loincs: ["3013-0"],
            displayId: "TBG",
			thresholds: [ { limit: 60, color: "#FF0000", isLowerLimit: false }],  
            position: { left: 1095, top: 1000 }
        },
		{
            name: "A1AT",
            loincs: ["6771-0"],
            displayId: "A1AT",
            thresholds: [ { limit: 2.18, color: "#FF0000", isLowerLimit: false }],  			
            position: { left: 1190, top: 1000 }
        },
		
		{
            name: "Digoxin",
            loincs: ["14698-5"],
            displayId: "Dig",
            thresholds: [{ limit: 2, color: "#FF0000", isLowerLimit: false }],  			
            yellowConditions: [{ conditionId: "DigC", monthsThreshold: 11 }],
            position: { left: 910, top: 1030 }
        },
		{
            name: "Dilantin",
            loincs: ["14877-5"],
            displayId: "Dil",
            thresholds: [ { limit: 80, color: "#FF0000", isLowerLimit: false }],  			
            position: { left: 1000, top: 1030 }
        },
		{
            name: "Lithium",
            loincs: ["14334-7"],
            displayId: "Li",
			thresholds: [ { limit: 1.2, color: "#FF0000", isLowerLimit: false }],  
            yellowConditions: [{ conditionId: "LithC", monthsThreshold: 5 }],
            position: { left: 1095, top: 1030 }
        },
		{
            name: "Carcinoembryonic_Ag",
            loincs: ["XXX-2279"],
            displayId: "CEA",
			thresholds: [ { limit: 3.9, color: "#FF0000", isLowerLimit: false }],  
            position: { left: 1190, top: 1030 }
        },
		
		
		
	    {
            name: "ANA",
            loincs: ["42254-3","8061-4","5048-4","XXX-2435"],
            displayId: "ANA",
            position: { left: 935, top: 1060 }
        },
		{
            name: "Cyclic_Citrullinated_Peptide",
            loincs: ["32218-0"],
            displayId: "CCP",
            thresholds: [{ limit: 3, color: "#FF0000", isLowerLimit: false }],  			
            position: { left: 1070, top: 1060 }
        },
		{
            name: "AFP",
            loincs: ["1834-1"],
            displayId: "AFP",
            thresholds: [ { limit: 3.9, color: "#FF0000", isLowerLimit: false }],  			
            position: { left: 1190, top: 1060 }
        },
		{
            name: "FIT",
			//loincs: ["58453-2","29771-3"],
            loincs: ["29771-3","58453-2"],
            displayId: "FIT_CSP",
            textThresholds: [{ value: "Pos", color: "#FF0000" }],
			//textThresholds: [{ value: "Pos", color: "#FF0000" },{ value: "Neg", color: "#003EFF" }],
            position: { left: 465, top: 820 }
        },

		{
            name: "TSH",
            loincs: ["3016-3"],
            displayId: "MonitorThyroidRx",
			thresholds: [{ limit: 0.3, color: "#003EFF", isLowerLimit: true }, { limit: 5.5, color: "#FF0000", isLowerLimit: false }],
            yellowConditions: [{ conditionId: "LithC", monthsThreshold: 5 },{ conditionId: "AmioC", monthsThreshold: 5 },{ conditionId: "ThyrC", monthsThreshold: 11 }],
            position: { left: 770, top: 633 }
        },
		{
            name: "ApolipoproteinB",
            loincs: ["1884-6","1871-3"],
            displayId: "ApolipoproteinB",
			thresholds: [{ limit: 0.8, color: "#FF0000", isLowerLimit: false }],
            position: { left: 770, top: 618 }
        },
		{
            name: "HIV",
            loincs: ["XXX-2887", "20447-9", "25835-0","48345-3"],
            displayId: "HIV",
			textThresholds: [{ value: "Pos", color: "#FF0000" }],
			position: { left: 485, top: 712 }
        },
		{
            name: "HBsAg",
            loincs: ["5195-3","5196-1"],
            displayId: "HBsAg",
			textThresholds: [{ value: "Pos", color: "#FF0000" }],
			position: { left: 485, top: 677 }
        },
		{
            name: "HBsAb",
            loincs: ["16935-9","5193-8"],
            displayId: "antiHBs",
			textThresholds: [{ value: "Pos", color: "#FF0000" }],
			position: { left: 485, top: 640 }
        },
		{
            name: "HCV",
            loincs: ["13955-0"], 
            displayId: "HCV",
            textThresholds: [{ value: "Pos", color: "#FF0000" }],
            position: { left: 485, top: 591 }
        },
		{
            name: "HAV",
            loincs: ["51913-2"],
            displayId: "HAV",
			textThresholds: [{ value: "Pos", color: "#FF0000" }],
			position: { left: 485, top: 626 }
        },
		
		
		
        // Add more labs here as needed
    ];
	
	function addOverlays() {
    const overlays = [
        { id: "Uric Acid", letter: "URIC", left: 900, top: 940 }, 
        { id: "AST", letter: "AST", left: 990, top: 940 },
        { id: "BNP", letter: "BNP", left: 1080, top: 940 },
		{ id: "Troponin", letter: "Trop", left: 1170, top: 940 },
		
		{ id: "CRP", letter: "CRP", left: 900, top: 970 }, 
        { id: "ESR", letter: "ESR", left: 990, top: 970 },
        { id: "Vitamin D", letter: "VitD", left: 1080, top: 970 },
		{ id: "RF", letter: "RF", left: 1170, top: 970 },
		 
        { id: "TTG", letter: "TTG", left: 900, top: 1000 }, 
        { id: "Fecal Calprotectin", letter: "FCAL", left: 990, top: 1000 },
        { id: "Thyroglobulin", letter: "TGB", left: 1080, top: 1000 },
		{ id: "Alpha-1 Antitrypsin Antibody", letter: "A1AT", left: 1170, top: 1000 },
		
		{ id: "Digoxin", letter: "DIG", left: 900, top: 1030 },
        { id: "Dilantin", letter: "DIL", left: 990, top: 1030 },
		{ id: "Lithium", letter: "LI", left: 1080, top: 1030 },
		{ id: "CEA", letter: "CEA", left: 1170, top: 1030 },
		
		{ id: "ANA", letter: "ANA", left: 900, top: 1060 },
		{ id: "Cyclic Citrullinated Peptide", letter: "CCP", left: 1035, top: 1060 },
		{ id: "Alpha-fetoprotein", letter: "AFP", left: 1170, top: 1060 },
    ];

// Create overlays and attach event listeners
overlays.forEach(overlay => {
    const div = document.createElement("div");
    div.className = "overlay"; // Use the CSS class for styling
    div.style.position = "absolute";
    div.style.left = `${overlay.left}px`;
    div.style.top = `${overlay.top}px`;
    div.style.width = "30px";
    div.style.height = "12px";
    div.style.zIndex = "10";
    div.style.fontSize = "11px"; 
    div.style.fontWeight = "bold"; 
    div.style.color = "black";
    div.style.textAlign = "center";
    div.style.cursor = "pointer"; // Add pointer cursor for better UX
    div.textContent = overlay.letter;

    // Attach click event listener
    div.addEventListener("click", () => toggleTest(overlay.id));

    document.body.appendChild(div);
});

}

function toggleTest(testName) {
    const textarea = document.FormName.AdditionalTestInstructions;

    // Check if the test name is already present
    if (textarea.value.includes(`${testName}, `)) {
        // Remove the test name
        textarea.value = textarea.value.replace(`${testName}, `, '');
    } else {
        // Add the test name
        textarea.value += `${testName}, `;
    }
}

addOverlays();



for (let i = 0; i < labsConfig.length; i++) { 
    const lab = labsConfig[i];

    // Ensure `loincs` is always an array
    if (!Array.isArray(lab.loincs)) {
        lab.loincs = [lab.loincs];
    }

    let resultReceived = false; // Flag to track if a result was received

    // Use a loop to go through each LOINC code in `loincs`
    for (let j = 0; j < lab.loincs.length; j++) {
        const loinc = lab.loincs[j];
        labReqEngine([loinc], lab.name, function(result) {
            resultReceived = true; // Mark that a result was received
            processMultiLoincResult(result, lab); // Process the result
        });
    }

    // Set a timeout to handle cases where no result is received
    setTimeout(() => {
        if (!resultReceived) {
            //console.log(`No results found for lab: ${lab.name}`);
            processMultiLoincResult(null, lab); // Process with null result
        }
    }, 500); // Adjust timeout as needed based on labReqEngine's expected response time
}

}



function processMultiLoincResult(result, lab) {

    // Reset yellow highlights before processing new results
    $(`#${lab.displayId}`).removeClass('yellow');

    // General logic for labs 
    if (result && result.date) {
        // Parse result date
        const resultDate = new Date(result.date);

        // Compare and update only if the result date is more recent
        if (!lab.latestDate || resultDate > lab.latestDate) {
            lab.latestValue = shortenResult(result.value); // Shorten the value here
            lab.latestDate = resultDate;
        }
    } else {
        // Handle case where no valid result is found
        lab.latestValue = undefined;
        lab.latestDate = undefined;
    }

    // Calculate months since the latest date (default to 1001 if no date)
    const monthsAgo = lab.latestDate ? monthsSince(lab.latestDate) : 1001;

    // Update the UI and apply yellow highlights
    updateMultiLoincLabUI(lab, monthsAgo);
    applyYellowHighlights(lab, monthsAgo);
	
	 // Dispatch a custom event to signal completion
    const event = new CustomEvent('multiLoincProcessed', { detail: { lab, monthsAgo } });
    document.dispatchEvent(event);
}




function shortenResult(value) {
    if (typeof value !== "string") return value; // Only process string values

    // Normalize the input for consistent comparison
    const standardizedValue = value.trim().toLowerCase();

    // Map for exact matches
    const map = { 
        negative: "Neg",
        positive: "Pos",
        nonreactive: "Neg",
        reactive: "Pos",
        "non-reactive": "Neg",
        "non reactive": "Neg"
    };

    // Check for exact matches
    if (map[standardizedValue]) {
        return map[standardizedValue];
    }

    // Generalized regex to handle partial/truncated words
    const regexPatterns = [
        { regex: /^non\s*-?\s*react/i, shortened: "Neg" }, // "Nonreact", "Non-reactive"
        { regex: /^react/i, shortened: "Pos" },           // "Reactive", "React"
        { regex: /^neg/i, shortened: "Neg" },             // "Negative", "Neg"
        { regex: /^pos/i, shortened: "Pos" }              // "Positive", "Pos"
    ];

    // Apply regex patterns
    for (const { regex, shortened } of regexPatterns) {
        if (regex.test(value)) {
            return shortened;
        }
    }

    // Return the original value if no match found
    return value;
}



// Helper function to calculate months difference
function monthsSince(date) {
    const currentDate = new Date();
    const yearsDiff = currentDate.getFullYear() - date.getFullYear();
    const monthsDiff = (yearsDiff * 12) + (currentDate.getMonth() - date.getMonth());

    // Adjust if the day of the month has not yet passed
    if (currentDate.getDate() < date.getDate()) {
        return monthsDiff - 1;
    }
    return monthsDiff;
}


function updateMultiLoincLabUI(lab) {
    const { displayId, latestValue, latestDate, thresholds, textThresholds, position, date, name, loincs, labname } = lab;

    const uniqueId = `${displayId}val`;

    // Remove any existing UI elements
    $(`#${uniqueId}`).remove();

    // Calculate display values
    const monthsAgo = latestDate ? monthsSince(latestDate) : 1001;
    const datePart = (date === "None" || !latestDate) ? "" : `${monthsAgo}M `;
    const namePart = (labname === "Yes" && latestValue !== undefined) ? `${name} ` : ""; // Show name only if labname is "Yes" and there is a value
    const valuePart = latestValue !== undefined ? `${latestValue}` : "";
    const displayValue = `${datePart}${namePart}${valuePart}`.trim();

    // Format title for tooltip
    const formattedDate = latestDate ? new Date(latestDate).toLocaleDateString() : "No Date";
    const title = `${name} : ${formattedDate}`;

    // Add UI element
    $("#page1").after(
        `<input 
            id="${uniqueId}" 
            type="text" 
            class="LabPb DoNotPrint" 
            style="position:absolute; left:${position.left}px; top:${position.top}px; width: 70px; text-align: right; outline: none;" 
            value="${displayValue}" 
            title="${title}"
            onclick="displayCumulativeLabResults('${name}', ${JSON.stringify(loincs).replace(/"/g, '&quot;')});"
        >`
    );

    // Apply color for numerical thresholds
    let color = ""; // Default to no color
    if (thresholds && Array.isArray(thresholds)) {
        thresholds.forEach((threshold) => {
            if (latestValue !== undefined) {
                if (latestValue < threshold.limit && threshold.isLowerLimit) {
                    color = threshold.color; // Blue if below lower limit
                } else if (latestValue > threshold.limit && !threshold.isLowerLimit) {
                    color = threshold.color; // Red if above upper limit
                }
            }
        });
    }

    // Apply color for textual thresholds
    if (!color && textThresholds && Array.isArray(textThresholds)) {
        textThresholds.forEach((textThreshold) => {
            if (latestValue === textThreshold.value) {
                color = textThreshold.color; // Apply color for matching textual result
            }
        });
    }

    // Apply color if determined
    if (color) {
        $(`#${uniqueId}`).css("color", color);
    }
}



// This is the function that can be called if there are multiple LOINCS for one lab value eg WCC and eGFR
function displayCumulativeLabResults(testName, loincCodes) {
    // Open a new window for displaying combined results
    const combinedWindow = window.open("", "_blank");
    combinedWindow.document.write("<html><head><title>Cumulative " + testName + " Results</title></head><body><h3>Cumulative " + testName + " Results</h3>");

    // Helper function to fetch and display results for each LOINC code
function fetchAndDisplay(loincCode) {
    const review = "https://" + currentHost + "/oscar/lab/CA/ON/labValues.jsp?testName=" + testName + "&demo=" + demo + "&labType=HL7&identifier=" + loincCode;
    //alert(review); // Debug: Show the URL being fetched

    return fetch(review)
        .then(response => {
            if (!response.ok) {
                //console.error("Failed to fetch for LOINC Code:", loincCode, "Status:", response.status);
                throw new Error("Failed to fetch lab results");
            }
            return response.text();
        })
        .then(data => {
            //console.log("Response for LOINC Code:", loincCode, data); // Debug: Log raw HTML

            // Create a temporary element to parse the response
            const tempDiv = document.createElement('div');
            tempDiv.innerHTML = data;

            // Check if the table has any rows in the <tbody>
            const table = tempDiv.querySelector('#tblDiscs tbody');
            if (table && table.querySelector('tr')) {
                //console.log("Results found for LOINC Code:", loincCode);

                // Modify the table's ID to avoid conflicts
                const modifiedData = data.replace(/id="tblDiscs"/g, `id="tblDiscs_${loincCode}"`);

                // Display the results in the new window
                combinedWindow.document.write("<h4>Results for LOINC Code: " + loincCode + "</h4>");
                combinedWindow.document.write(modifiedData);
            } else {
                //console.log("No results found for LOINC Code:", loincCode);
                //combinedWindow.document.write("<p>No results found for LOINC Code: " + loincCode + "</p>");
            }
        })
        .catch(error => {
            //console.error("Error fetching data for LOINC Code:", loincCode, error);
            combinedWindow.document.write("<p>Error fetching data for LOINC Code " + loincCode + ": " + error.message + "</p>");
        });
}


    // Fetch and display results for all LOINC codes, then close the document
    Promise.all(loincCodes.map(fetchAndDisplay)).then(() => {
        combinedWindow.document.write("</body></html>");
        combinedWindow.document.close();
    }).catch(error => {
        combinedWindow.document.write("<p>Error loading results: " + error.message + "</p></body></html>");
        combinedWindow.document.close();
    });
}


function applyYellowHighlights(lab, monthsAgo) {  
    // Check if yellowConditions exists and is an array
    if (!lab.yellowConditions || !Array.isArray(lab.yellowConditions)) { 
        return; // Exit if there are no yellow conditions
    }

    lab.yellowConditions.forEach(condition => {
        const conditionId = `#${condition.conditionId}`;

        // Trigger yellow highlight only if monthsAgo is greater than the threshold and not undefined
        if ((monthsAgo === undefined || monthsAgo > condition.monthsThreshold) &&
            $(conditionId).css("color") === "rgb(255, 0, 0)") {
            $(`#${lab.displayId}`).addClass('yellow');
        }
    });
}




window.onload = () => {
    setTimeout(() => {
        const FIT_CSPvalElement = document.getElementById("FIT_CSPval");
        if (FIT_CSPvalElement) {
            console.log("FIT_CSPval element found:", FIT_CSPvalElement);
            handleFIT(FIT_CSPvalElement.value.trim());
        } else {
            console.error("FIT_CSPval not found after multiLoincProcessed. Assuming no FIT test result.");
            handleFIT(""); // Pass an empty string to indicate no FIT test result
        }
    }, 1000);
};

function handleFIT(FIT_CSPval = "") {
    const age = parseFloat(document.getElementById("PatientAge").value) || 0; // Default to 0 if not a number
    const FUYear = $('#FUYear').val().trim(); // Retrieve colonoscopy due input
    const FIT_CSP = $('#FIT_CSP'); // Target the input for styling
    const FUYearInput = $('#FUYear'); // Target FUYear for styling

    // Parse FIT_CSPval
    const FITmonths = parseInt(FIT_CSPval.match(/\d+/)?.[0] || "1001"); // Default to 1001 months if no result
    const FITresult = FIT_CSPval.match(/(?<=\b\d+M\s?)(.+)$/i)?.[0]?.trim() || ""; // Extract result, default empty

    console.log(`Age: ${age}, FITmonths: ${FITmonths}, FITresult: ${FITresult}`);
    console.log(`FUYear: ${FUYear}`);

    // Conditions to turn FIT_CSP yellow
    const isInAgeRange = age >= 50 && age <= 74;
    const isFITMissing = isNaN(FITmonths) || FITmonths > 23;

    // Colonoscopy check
    const yearRegex = /\b\d{2,4}\b/;
    let yearNumber = null;

    if (yearRegex.test(FUYear)) {
        yearNumber = parseInt(FUYear.match(yearRegex)[0]);
        if (yearNumber < 100) {
            const currentYear = new Date().getFullYear();
            const twoDigitYearThreshold = currentYear % 100 + 5;
            yearNumber += yearNumber <= twoDigitYearThreshold ? 2000 : 1900;
        }
    }

    const isDonePresent = /done/i.test(FUYear);
    const currentYear = new Date().getFullYear();

    console.log(`Year parsed: ${yearNumber}, isDonePresent: ${isDonePresent}`);

    if (
        !FUYear &&
        isFITMissing &&
        isInAgeRange
    ) {
        FIT_CSP.addClass("yellow");
        console.log("Condition: No FUYear, FIT missing, Age in range");
    }

    if (
        isDonePresent &&
        yearNumber + 10 <= currentYear &&
        isFITMissing &&
        isInAgeRange
    ) {
        FIT_CSP.addClass("yellow");
        console.log("Condition: Colonoscopy > 10 years, FIT missing, Age in range");
    }
}



    // This adds Done to the Colonoscopy Due if there is a value
    document.getElementById('FUYear').addEventListener('dblclick', function() {
    const input = this;
    const value = input.value;
    
    if (!!value && !value.startsWith('Done')) {
        input.value = 'Done ' + value;
    }
});


		
function jQ_append(id_of_input, text, id_of_input2, text2) {
	$(id_of_input).val($(id_of_input).val() + text).prop("readonly", true).addClass("fakelabel");
	$(id_of_input2).val($(id_of_input2).val() + text2).prop("readonly", true).addClass("fakelabel");
}

function medicalIssues() {
	AddIfMissingTitle('CHF1', "CHF: eGFR/Na/K Q6M\nBaseline FBS/Lipid profile/ALT/ALB/CBC \n");
	AddIfMissingTitle('CKD1', "CKD: eGFR/Na/K Q6M\nA1C/ACR/CBC/Na/K Q12M\n*Lipid profile Q24M\n*Not necessary if on statin\n");
	AddIfMissingTitle('DM1', "DM: A1C Q6M\neGFR/Na/K/ACR/*Lipid profile Q12M\n*Not necessary if on statin\n");
	AddIfMissingTitle('HBP1', "HBP: A1C/eGFR/Na/K Q12M\n*Lipid profile Q60M\n*Not necessary if on statin\n");

	// Checks for medications
	let history3 = document.getElementById('history3').value;
	let history3Split = history3.split("]]-----");
	history3 = history3Split.pop().toUpperCase();

	let history4 = document.getElementById('Meds').value;
	let history4Split = history4.split("]]-----");
	history4 = history4Split.pop().toUpperCase();

	document.getElementById('searchboxRx').value = history4 + '\n' + history3;


// Function to reset the custom tooltip content and styling
function resetTooltip() {
    let tooltip = document.getElementById('TheraDMTooltip');
    tooltip.innerHTML = 
        "STATIN: titrate statin dose not LDL. Baseline lipid profile, ALT, CK. Then ALT at 3M,12M,then PRN.<br>" +
        "ATYPICAL ANTIPSYCHOTICS: A1C Q12M, Lipid profile Q24M.<br>" +
        "DIGOXIN: eGFR/Na/K/Dig level Q12M<br>" +
        "SPIRONOLACTONE: eGFR/Na/K Q3M<br>"+
		"METFORMIN: eGFR/CBC Q12M<br>"+
		"METHOTREXATE: eGFR/ALT/CBC Q2M<br>"+
		"LITHIUM: eGFR/Na/K/CBC/TSH/Lithium level Q6M<br>"+
		"THYROID: TSH Q12M<br>"+
		"AMIODARONE: ALT/TSH Q6M<br>"+
		"ACCUTANE: Lipid profile/ALT Q1M<br>"+
		"PHENYTOIN: ALT/CBC Q12M<br>"+
		"VALPROATE: ALT/CBC Q12M<br>"+
		"NOAC: eGFR Q6-12M<br>";
    tooltip.style.color = '';  // Reset color
    tooltip.style.fontWeight = '';  // Reset font weight
}

// Function to highlight specific medication details in the custom tooltip
function highlightMedicationInTooltip(medicationText) {
    let tooltip = document.getElementById('TheraDMTooltip');
    tooltip.innerHTML = tooltip.innerHTML.replace(
        medicationText,
        '<span style="color: red;">' + medicationText + '</span>'
    );
}


// Reset the tooltip to show all medication recommendations
resetTooltip();

// Statin medications check
let FreeText = /ATORVASTATIN|FLUVASTATIN|LOVASTATIN|PRAVASTATIN|ROSUVASTATIN|SIMVASTATIN/i;
let string = document.getElementById("searchboxRx").value;
let match = string.search(FreeText);
if (match !== -1) {
    $('#StatinC').css('color', 'red');
    $('#TheraDM').css('color', 'red');
    highlightMedicationInTooltip("STATIN: titrate statin dose not LDL. Baseline lipid profile, ALT, CK. Then ALT at 3M,12M,then PRN.");
}

// Atypical antipsychotics check
FreeText = /AntipsychoticAtypical|risperidone|quetiapine|olanzapine|aripiprazole|clozapine/i;
string = document.getElementById("searchboxRx").value;
match = string.search(FreeText);
if (match !== -1) {
	$('#AAPsyC').css('color', 'red');
	$('#TheraDM').css('color', 'red');
    highlightMedicationInTooltip("ATYPICAL ANTIPSYCHOTICS: A1C Q12M, Lipid profile Q24M.");
}

// Digoxin check
FreeText = /Digoxin/i;
string = document.getElementById("searchboxRx").value;
match = string.search(FreeText);
if (match !== -1) {
	$('#DigC').css('color', 'red');
	$('#TheraDM').css('color', 'red');
    highlightMedicationInTooltip("DIGOXIN: eGFR/Na/K/Dig level Q12M");
}

// Spironolactone check
FreeText = /Spironolactone/i;
string = document.getElementById("searchboxRx").value;
match = string.search(FreeText);
if (match !== -1) {
	$('#SpiroC').css('color', 'red');
	$('#TheraDM').css('color', 'red');
    highlightMedicationInTooltip("SPIRONOLACTONE: eGFR/Na/K Q3M");
}

	FreeText = /Metformin/i;
	string = document.getElementById("searchboxRx").value;
	match = string.search(FreeText);
	if (match !== -1) {
		$('#MetfC').css('color', 'red');
		$('#TheraDM').css('color', 'red');
		highlightMedicationInTooltip("METFORMIN: eGFR/CBC Q12M");
	}
	FreeText = /Methotrexate/i;
	string = document.getElementById("searchboxRx").value;
	match = string.search(FreeText);
	if (match !== -1) {
		$('#MethoC').css('color', 'red');
		$('#TheraDM').css('color', 'red');
		highlightMedicationInTooltip("METHOTREXATE: eGFR/ALT/CBC Q2M");
	}

	FreeText = /LITHIUM/i;
	string = document.getElementById("searchboxRx").value;
	match = string.search(FreeText);
	if (match !== -1) {
		$('#LithC').css('color', 'red');
		$('#TheraDM').css('color', 'red');
		highlightMedicationInTooltip("LITHIUM: eGFR/Na/K/CBC/TSH/Lithium level Q6M");
	}

	FreeText = /LEVOTHYROXINE|THYROID/i;
	string = document.getElementById("searchboxRx").value;
	match = string.search(FreeText);
	if (match !== -1) {
		$('#ThyrC').css('color', 'red');
		$('#TheraDM').css('color', 'red');
		highlightMedicationInTooltip("THYROID: TSH Q12M");
	}

	FreeText = /AMIODARONE/i;
	string = document.getElementById("searchboxRx").value;
	match = string.search(FreeText);
	if (match !== -1) {
		$('#AmioC').css('color', 'red');
		$('#TheraDM').css('color', 'red');
		highlightMedicationInTooltip("AMIODARONE: ALT/TSH Q6M");
	}

	FreeText = /ISOTRETINOIN/i;
	string = document.getElementById("searchboxRx").value;
	match = string.search(FreeText);
	if (match !== -1) {
		$('#AccutC').css('color', 'red');
		$('#TheraDM').css('color', 'red');
		highlightMedicationInTooltip("ACCUTANE: Lipid profile/ALT Q1M");
	}

	FreeText = /PHENYTOIN/i;
	string = document.getElementById("searchboxRx").value;
	match = string.search(FreeText);
	if (match !== -1) {
		$('#PhenyC').css('color', 'red');
		$('#TheraDM').css('color', 'red');
		highlightMedicationInTooltip("PHENYTOIN: ALT/CBC Q12M");
	}

	FreeText = /VALPROIC/i;
	string = document.getElementById("searchboxRx").value;
	match = string.search(FreeText);
	if (match !== -1) {
		$('#ValproC').css('color', 'red');
		$('#TheraDM').css('color', 'red');
		highlightMedicationInTooltip("VALPROATE: ALT/CBC Q12M");
	}
	FreeText = /DABIGATRAN|RIVAROXABAN|APIXABAN/i;
	string = document.getElementById("searchboxRx").value;
	match = string.search(FreeText);
	if (match !== -1) {
		$('#NOACC').css('color', 'red');
		$('#TheraDM').css('color', 'red');
		highlightMedicationInTooltip("NOAC: eGFR Q6-12M");
	}

}
	

/*
 * toggle the details about each lab result.
 */
jQuery.fn.slideFadeToggle = function(easing, callback) {
	return this.animate({ opacity: 'toggle', height: 'toggle' }, 'fast', easing, callback);
};

function showLabDetails(lab) {
	let close = jQuery("<a>").attr("id","closeLabDetail").text("close");

	let patientdetail = jQuery("<div>").addClass("patientDetail")
		.append(jQuery("<span>").text(PATIENT_NAME).prepend(jQuery("<label>").text("name")))
		.append(jQuery("<span>").text(PATIENT_GENDER).prepend(jQuery("<label>").text("gender")))
		.append(jQuery("<span>").text(PATIENT_DOB).prepend(jQuery("<label>").text("dob")))
		.append(jQuery("<span>").text(PATIENT_AGE).prepend(jQuery("<label>").text("age")));

	let labdetail = jQuery("<ul>")
		.append(jQuery("<li>").text(lab.name).prepend(jQuery("<label>").text("Name: ")))
		.append(jQuery("<li>").text(lab.date).prepend(jQuery("<label>").text("Observation Date: ")))
		.append(jQuery("<li>").text(lab.value + " " + lab.unit).prepend(jQuery("<label>").text("Result: ")))
		.append(jQuery("<li>").text(lab.abnormal).prepend(jQuery("<label>").text("Status: ")))
		.append(jQuery("<li>").text(lab.range).prepend(jQuery("<label>").text("Range: ")));

	jQuery("#labDetail").empty()
		.append(close)
		.append(patientdetail)
		.append(labdetail).slideFadeToggle();

	jQuery("#closeLabDetail").on('click', function(){
		jQuery("#labDetail").empty().slideFadeToggle();
	});
}

/*
 * The following are adaptations of methods that were introduced by a previous author.
 * It was less time-consuming - and less error-prone - to modify these methods instead of
 * completely refactoring the workflow.
 * A refactor should be considered in order to improve maintainability.
 */
 

var currentHost =window.location.hostname; //alert(currentHost);
var currentSearch = window.location.search; //alert(currentSearch);
var demo1 = currentSearch.split("&demographic_no=")[1]; //alert(demo1);
var demo = demo1.split("&appointment")[0];  //alert(demo);

var clickTimer = null;


// Insert medical conditions
function medicalConditions() {
	$("#page1").after('<input id="DMC" type="button" value="DM" class="LabP3 DoNotPrint labButton" style="left:860px;">')
	.after('<input id="HBPC" type="button" value="HBP" class="LabP3 DoNotPrint labButton" style="left:930px;">')
	.after('<input id="CHFC" type="button" value="CHF" class="LabP3 DoNotPrint labButton" style="left:1000px;">')
	.after('<input id="CKDC" type="button" value="CKD" class="LabP3 DoNotPrint labButton" style="left:1070px;">')
	.after('<input id="AmioC" type="button" value="Amiodarone" class="LabP4 DoNotPrint labButton" style="left:1070px;">')
	.after('<input id="AAPsyC" type="button" value="AAPsy" class="LabP4 DoNotPrint labButton" style="left:1000px;">')
	.after('<input id="DigC" type="button" value="Digoxin" class="LabP4 DoNotPrint labButton" style="left:930px;">')
	.after('<input id="MetfC" type="button" value="Metformin" class="LabP4 DoNotPrint labButton" style="left:860px;">')
	.after('<input id="LithC" type="button" value="Lithium" class="LabP5 DoNotPrint labButton" style="left:1070px;">')
	.after('<input id="MethoC" type="button" value="Methotrex" class="LabP5 DoNotPrint labButton" style="left:930px;">')
	.after('<input id="PhenyC" type="button" value="Phenytoin" class="LabP5 DoNotPrint labButton" style="left:1000px;">')
	.after('<input id="StatinC" type="button" value="Statin" class="LabP5 DoNotPrint labButton" style="left:860px;">')
	.after('<input id="ThyrC" type="button" value="Thyroxin" class="LabP6 DoNotPrint labButton" style="left:860px;">')
	.after('<input id="ValproC" type="button" value="Valproate" class="LabP6 DoNotPrint labButton" style="left:1000px;">')
	.after('<input id="AccutC" type="button" value="Accutane" class="LabP6 DoNotPrint labButton" style="left:1070px;">')
	.after('<input id="SpiroC" type="button" value="Spironolac" class="LabP6 DoNotPrint labButton" style="left:930px;">')
	.after('<input id="NOACC" type="button" value="NOAC" class="LabP6 DoNotPrint labButton" style="left:1000px;">')
	.after('<input id="0months" type="hidden" value="Due\nNow" class="DoNotPrint" style="position:absolute;left:847px;top:680px;width:40px;height:34px;cursor:pointer;background-color:yellow;" onclick="Period0()">')
	.after('<input id="3months" type="hidden" value="3M" class="DoNotPrint" style="position:absolute;left:847px;top:725px;width:40px;cursor:pointer;" onclick="Period3()" title="Click twice">')
	.after('<input id="6months" type="hidden" value="6M" class="DoNotPrint" style="position:absolute;left:847px;top:750px;width:40px;cursor:pointer;" onclick="Period6()" title="Click twice">')
	.after('<input id="12months" type="hidden" value="12M" class="DoNotPrint" style="position:absolute;left:845px;top:775px;width:44px;cursor:pointer;" onclick="Period12()" title="Click twice">');
}

// alert if any yellow check boxes
function alertYellow() {
	let x = $("input[type=text].yellow").val();
	if (x !== "") {
		$("#0months").css("background-color", "white");
	}
}

function Period0() {
	if ($("#0months").css("background-color") == 'rgb(255, 255, 0)') {
		checkBox();
		$('#PatientInstructions').val($('#PatientInstructions').val() + 'Blood work is due now.').css('font-weight', '700');
	}
	if ($("#0months").css("background-color") != 'rgb(255, 255, 0)') {
		$("#12months").css("background-color", "white");
		$("#0months").css("background-color", "yellow");
		$("#3months").css("background-color", "white");
		$("#6months").css("background-color", "white");
		RepeatPopValues();
	}

}

function Period3() {
	let d = new Date();
	let mon = (d.getMonth() + 3);
	let months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December", "January", "February", "March"];
	let monthName = months[mon];
	if ($("#3months").css("background-color") == 'rgb(255, 255, 0)') {
		checkBox();
		$('#PatientInstructions').val($('#PatientInstructions').val() + 'Blood work is due in ' + monthName + '.').css('font-weight', '700');
	}
	if ($("#3months").css("background-color") != 'rgb(255, 255, 0)') {
		$("#12months").css("background-color", "white");
		$("#3months").css("background-color", "yellow");
		$("#0months").css("background-color", "white");
		$("#6months").css("background-color", "white");
		RepeatPopValues();
	}
}

function Period6() {
	let d = new Date();
	let mon = (d.getMonth() + 6);
	let months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December", "January", "February", "March", "April", "May", "June"];
	let monthName = months[mon];
	if ($("#6months").css("background-color") == 'rgb(255, 255, 0)') {
		checkBox();
		$('#PatientInstructions').val($('#PatientInstructions').val() + 'Blood work is due in ' + monthName + '.').css('font-weight', '700');
	}
	if ($("#6months").css("background-color") != 'rgb(255, 255, 0)') {
		$("#12months").css("background-color", "white");
		$("#6months").css("background-color", "yellow");
		$("#3months").css("background-color", "white");
		$("#0months").css("background-color", "white");
		RepeatPopValues();
	}
}

function Period12() {
	let d = new Date();
	let mon = (d.getMonth());
	let months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
	let monthName = months[mon];
	if ($("#12months").css("background-color") == 'rgb(255, 255, 0)') {
		checkBox();
		$('#PatientInstructions').val($('#PatientInstructions').val() + 'Blood work is due next year, in ' + monthName + '.').css('font-weight', '700');
	}
	if ($("#12months").css("background-color") != 'rgb(255, 255, 0)') {
		$("#12months").css("background-color", "yellow");
		$("#6months").css("background-color", "white");
		$("#3months").css("background-color", "white");
		$("#0months").css("background-color", "white");
		RepeatPopValues();
	}
}

function checkBox() {
	$("input[type=text].yellow").val("X");
	if (($("#DIGC").css("background-color")) == 'rgb(255, 255, 0)') {
		ZDIGTF();
	}
	if (($("#LITHC").css("background-color")) == 'rgb(255, 255, 0)') {
		ZLITHTF();
	}
	if ((($("#GlucoseFasting").css("background-color")) == 'rgb(255, 255, 0)')) {
		document.FormName.PatientInstructions.value += 'Nothing to eat or drink, except for water, for 8-10 hours prior to test. ';
		document.FormName.FastingTime.value = '10';
	}
}





function DMLipid() {
	let FreeText = /STATIN/i;
	let match = allRx.search(FreeText);
	if (match == -1) {  //not on statin, check lipid profile
		$('#Lipid_full').val('X');
	}
}

//Peters Code
function StartAddIfMissingTitle(x, content) {
	document.getElementById(x).title = content
}

function AddIfMissingTitle(x, content) {
	if (document.getElementById(x).title.indexOf(content) == -1) {
		document.getElementById(x).title += content
	}
}

function AddIfMissingStyle(x, content) {
	if (document.getElementById(x).style.cssText.indexOf(content) == -1) {
		document.getElementById(x).style.cssText += "; " + content
	}
}

function AddIfMissingHTML(x, content, test) {
	if (document.getElementById(x).innerHTML.indexOf(test) == -1) {
		document.getElementById(x).innerHTML += content
	}
}

function hilite(me) {
	document.getElementById(me).style.color = 'red';
}

function getLines(x) {
	let multi = document.getElementById(x).value;
	let lines = multi.split("\n");
	let numLines = lines.length;
	return numLines;
}


function getLabAge(DateId) {
	let num_months = 1200;
	//"2012-12-06 00:00:00"
	let strDate = document.getElementById(DateId).value;
	if (strDate.length > 9) {
		let dateParts = (strDate.substring(0, 10)).split("-");
		let date = new Date(dateParts[0], (dateParts[1] - 1), dateParts[2]);
		let today = new Date();
		let milli_today = today.getTime();
		let milli_date = date.getTime();
		let diff = milli_today - milli_date;
		num_months = Math.round(diff / 2628000000); //(((diff / 1000)s / 60)m / 60)h / 24d / 365y * 12m
	} else {
		document.getElementById(DateId).value = "?";
	}
	return num_months;
}

function Framingham1991(age, female, smoking, systolic, lipid_ratio, predict_length) {
	let chd_theta0 = 0.9145;
	let chd_theta1 = -0.2784;
	let chd_b0 = 15.5305;
	let chd_b1 = 28.4441;  // female
	let chd_b2 = -1.4792;  // log(age)
	let chd_b3 = 0;        // log(age)^2
	let chd_b4 = -14.4588; // log(age)*sex
	let chd_b5 = 1.8515;   // log(age)^2*sex
	let chd_b6 = -0.9119;  // log(SPB)
	let chd_b7 = -0.2767;  // smoking
	let chd_b8 = -0.7181;  // log(total_c/hdl_c)

	let chd_b1out = chd_b1 * female;
	let chd_b2out = chd_b2 * Math.log(age);
	let chd_b3out = chd_b3 * Math.log(age) * Math.log(age);
	let chd_b4out = chd_b4 * Math.log(age) * female;
	let chd_b5out = chd_b5 * Math.log(age) * Math.log(age) * female;
	let chd_b6out = chd_b6 * Math.log(systolic);
	let chd_b7out = chd_b7 * smoking;
	let chd_b8out = chd_b8 * Math.log(lipid_ratio);

	let mean = chd_b0 + chd_b1out + chd_b2out + chd_b3out + chd_b4out + chd_b5out + chd_b6out + chd_b7out + chd_b8out;

	let log_var = chd_theta0 + chd_theta1 * mean;

	let u = (Math.log(predict_length) - mean) / Math.exp(log_var);

	chd_risk = (1.0 - Math.exp(-Math.exp(u))) * 0.75;  // the calculation is the simpler 1991 Framingham which is 20-30% high

	return chd_risk;
}

// function GetFraminghamCHDRiskPoints(age, sex, smoking, systolic, treated_bp, total_chol, hdl_chol)

function GetFraminghamCHDRiskPoints(age, female, smoking, systolic, treated_bp, chol, hdl_chol) {

	let age_points = 0;

	if (age >= 20 && age <= 34) {
		age_points = (female == 1) ? -7 : -9;
	} else if (age <= 39) {
		age_points = (female == 1) ? -3 : -4;
	} else if (age <= 44) {
		age_points = (female == 1) ? 0 : 0;
	} else if (age <= 49) {
		age_points = (female == 1) ? 3 : 3;
	} else if (age <= 54) {
		age_points = (female == 1) ? 6 : 6;
	} else if (age <= 59) {
		age_points = (female == 1) ? 8 : 8;
	} else if (age <= 64) {
		age_points = (female == 1) ? 10 : 10;
	} else if (age <= 69) {
		age_points = (female == 1) ? 12 : 11;
	} else if (age <= 74) {
		age_points = (female == 1) ? 14 : 12;
	} else if (age <= 79) {
		age_points = (female == 1) ? 16 : 13;
	}

	let chol_points = 0;
	let smoking_points = 0;

	if (age >= 20 && age <= 39) {
		if (smoking == 1)
			smoking_points = (female == 1) ? 9 : 8;
		if (chol <= 4.14)
			chol_points = 0;
		else if (chol <= 5.19)
			chol_points = (female == 1) ? 4 : 4;
		else if (chol <= 6.19)
			chol_points = (female == 1) ? 8 : 7;
		else if (chol <= 7.2)
			chol_points = (female == 1) ? 11 : 9;
		else
			chol_points = (female == 1) ? 13 : 11;
	} else if (age <= 49) {
		if (smoking == 1)
			smoking_points = (female == 1) ? 7 : 5;

		if (chol <= 4.14)
			chol_points = 0;
		else if (chol <= 5.19)
			chol_points = (female == 1) ? 3 : 3;
		else if (chol <= 6.19)
			chol_points = (female == 1) ? 6 : 5;
		else if (chol <= 7.2)
			chol_points = (female == 1) ? 8 : 6;
		else
			chol_points = (female == 1) ? 10 : 8;
	} else if (age <= 59) {
		if (smoking == 1)
			smoking_points = (female == 1) ? 4 : 3;

		if (chol <= 4.14)
			chol_points = 0;
		else if (chol <= 5.19)
			chol_points = (female == 1) ? 2 : 2;
		else if (chol <= 6.19)
			chol_points = (female == 1) ? 4 : 3;
		else if (chol <= 7.2)
			chol_points = (female == 1) ? 5 : 4;
		else
			chol_points = (female == 1) ? 7 : 5;
	} else if (age <= 69) {
		if (smoking == 1)
			smoking_points = (female == 1) ? 2 : 1;

		if (chol <= 4.14)
			chol_points = 0;
		else if (chol <= 5.19)
			chol_points = (female == 1) ? 1 : 1;
		else if (chol <= 6.19)
			chol_points = (female == 1) ? 2 : 1;
		else if (chol <= 7.2)
			chol_points = (female == 1) ? 3 : 2;
		else
			chol_points = (female == 1) ? 4 : 3;
	} else if (age <= 79) {
		if (smoking == 1)
			smoking_points = (female == 1) ? 1 : 1;

		if (chol <= 4.14)
			chol_points = 0;
		else if (chol <= 5.19)
			chol_points = (female == 1) ? 1 : 0;
		else if (chol <= 6.19)
			chol_points = (female == 1) ? 1 : 0;
		else if (chol <= 7.2)
			chol_points = (female == 1) ? 2 : 1;
		else
			chol_points = (female == 1) ? 2 : 1;
	}

	let hdl_points = 0;

	if (hdl_chol >= 1.55)
		hdl_points = -1;
	else if (hdl_chol > 1.3)
		hdl_points = 0;
	else if (hdl_chol > 1.04)
		hdl_points = 1;
	else
		hdl_points = 2;

	let systolic_points = 0;

	if (treated_bp == 0) {
		//untreated bp
		if (systolic < 120)
			systolic_points = (female == 1) ? 0 : 0;
		else if (systolic < 129)
			systolic_points = (female == 1) ? 1 : 0;
		else if (systolic < 139)
			systolic_points = (female == 1) ? 2 : 1;
		else if (systolic < 159)
			systolic_points = (female == 1) ? 3 : 1;
		else
			systolic_points = (female == 1) ? 4 : 2;
	} else {
		//treated bp
		if (systolic < 120)
			systolic_points = (female == 1) ? 0 : 0;
		else if (systolic < 129)
			systolic_points = (female == 1) ? 3 : 1;
		else if (systolic < 139)
			systolic_points = (female == 1) ? 4 : 2;
		else if (systolic < 159)
			systolic_points = (female == 1) ? 5 : 2;
		else
			systolic_points = (female == 1) ? 6 : 3;
	}

	let total_points = age_points + chol_points + smoking_points + hdl_points + systolic_points;

	if (female == 0) {
		//male
		if (total_points <= 4)
			return 0.01;
		else if (total_points <= 6)
			return 0.02;
		else if (total_points <= 7)
			return 0.03;
		else if (total_points <= 8)
			return 0.04;
		else if (total_points <= 9)
			return 0.05;
		else if (total_points <= 10)
			return 0.06;
		else if (total_points <= 11)
			return 0.08;
		else if (total_points <= 12)
			return 0.10;
		else if (total_points <= 13)
			return 0.12;
		else if (total_points <= 14)
			return 0.16;
		else if (total_points <= 15)
			return 0.20;
		else if (total_points <= 16)
			return 0.25;
		else
			return 0.30;
	} else {
		//female
		if (total_points <= 12)
			return 0.01;
		else if (total_points <= 14)
			return 0.02;
		else if (total_points <= 15)
			return 0.03;
		else if (total_points <= 16)
			return 0.04;
		else if (total_points <= 17)
			return 0.05;
		else if (total_points <= 18)
			return 0.06;
		else if (total_points <= 19)
			return 0.08;
		else if (total_points <= 20)
			return 0.11;
		else if (total_points <= 21)
			return 0.14;
		else if (total_points <= 22)
			return 0.17;
		else if (total_points <= 23)
			return 0.22;
		else if (total_points <= 24)
			return 0.27;
		else
			return 0.30;
	}
}

function decisionSupport() {
	if (document.getElementById('counter').value.length < 1) {
		//The searchbox picks up user input and must be pretty
		document.getElementById('counter').value = '1';
		let history2 = document.getElementById('history2').value;
		let history2Split = history2.split("]]-----\n");
		let History2 = history2Split.pop().toUpperCase();
		document.getElementById('searchbox').value = History2;
		let meds = document.getElementById('Meds').value.toString();
		let FreeText = /\(.*\)/g;
		let string = meds;
		document.getElementById('searchboxRx').value = string.replace(FreeText, "");
		document.getElementById('history2').value = history2Split.join("\n");
	}
	//dynamically resize based on number of lines
	document.getElementById('searchbox').style.height = 19 + getLines('searchbox') * 10;
	document.getElementById('searchboxRx').style.height = 19 + getLines('searchboxRx') * 10;

	//The searchbox has only the first bullet of the history and possibly user input
	//all takes all the history items and anything in the disease registry
	let all = document.getElementById('searchbox').value + document.getElementById('dxlist').value;
	allRx = document.getElementById('searchboxRx').value;

	function SystolicPressure() {
		let ref = document.getElementById('BP').value.toString();
		let mySplitResult = ref.split('/');
		let x = mySplitResult[0];
		return x;
	}

	function HasDM() {
		let FreeText = /Diabetes Mellitus|IDDM|\sDM\s|T2DM|T1DM|type 2 DM|type2 DM|type1 DM|NIDDM|type 1 DM|T2DM|T2 DM|\sDM2\s/i;
		let match = all.search(FreeText);
		FreeText = /METFORMIN|INSULIN|GLYBURIDE|GLICLAZIDE/i;
		let match2 = allRx.search(FreeText);
		let theA1C = parseFloat(document.getElementById('A1Cvalue').value);
		if ((match !== -1) || (match2 !== -1) || (theA1C > 6.5)) {
			$('#DMC').css('color', 'red');
			$('#DMtitle').css('color', 'red');
			$('#hasDiabetes').val('1');
			return true;
		}
		return false;
	}

	function HasCAD() {
		let FreeText = /ischemi|IHD|\sCAD\s|\sMI\s|stent|coronary|CABG/i;
		let match = all.search(FreeText);
		FreeText = /NITROGLYCERIN|CLOPIDOGREL/i;
		let match2 = allRx.search(FreeText);
		if ((match !== -1) || (match2 !== -1)) {
			return true;
		}
		return false;
	}

	function HasCHF() {
		let FreeText = /CHF|Congestive cardiac|Congestive heart failure|heart failure|LVF|RVF|Systolic dysfunction|Diastolic dysfunction|pulmonary edema|pulmonary oedema|\sHF\s/i;
		let match = all.search(FreeText);
		if (match !== -1) {
			$('#CHFC').css('color', 'red');
			$('#CHFtitle').css('color', 'red');
			return true;
		}
		return false;
	}

	function HasHTN() {
		let FreeText = /HBP|Hypertension|Elevated BP|\sBP\s|\sHTN\s/i;
		let match = all.search(FreeText);
		if (match !== -1) {
			$('#HBPC').css('color', 'red');
			$('#HBPtitle').css('color', 'red');
			$('#hasBP').val('1');
			return true;
		}
		return false;
	}

	function HasCKD() {
		let FreeText = /CKD|Chronic kidney disease|Renal failure|renal insufficiency|\sCRF\s/i;
		let match = all.search(FreeText);
		let estGFR = parseFloat(document.getElementById('eGFRvalue').value);
		if ((match !== -1) || ((estGFR < 45) && (estGFR > 0))) {
			$('#CKDC').css('color', 'red');
			$('#CKDtitle').css('color', 'red');
			return true;
		}
		return false;
	}

	function OnStatin() {
		let FreeText = /STATIN/i;
		let match2 = allRx.search(FreeText);
		if (match2 !== -1) {
			return true;
		}
		return false;
	}

	function OnAAPsy() {
		let FreeText = /AntipsychoticAtypical|risperidone|quetiapine|olanzapine|aripiprazole|clozapine/i;
		let match2 = allRx.search(FreeText);
		if (match2 !== -1) {
			return true;
		}
		return false;
	}

	function OnAccutane() {
		let FreeText = /ISOTRETINOIN/i;
		let match2 = allRx.search(FreeText);
		if (match2 !== -1) {
			return true;
		}
		return false;
	}


// LIPID assessment
// NICE 2010 recommends that all adults 40-74 should have an estimate of CVD risk and if elevated to get a cholesterol.
// If the risk remains above 20% after lifestyle modifications Simvastatin 40mg should be considered.
// The logic we use here is that adults 35-75 without diabetes, CKD or IHD can be risk assessed by Framingham.
// 75 is the upper age cut off as some at that age are fit and may benefit and others are infirm and are unlikely to gain
// If at low risk they can have the lipids done q 5 years.  The pretest risk threshold for annual testing is set at 15%.
// This tool just simplifies population based screening, but it is not a substitute for critical thinking
// eg. Framingham does not assess the added risk of low SES
// nor
// a family history of premature CHD
// (a first degree male relative with CHD under age 50 or female relative under age 60 can double the risk).


	let age = parseFloat(document.getElementById("PatientAge").value);
	let sex = (document.getElementById("PatientGender").value == 'M') ? 0 : 1; //1 if female, 0 if male
	//let smoking        = ((document.getElementById('smoker').value == 'yes')||(document.getElementById('smoker').value == 'Yes')||(document.getElementById('dailySmokes').value >0)||(document.getElementById('PacksPerDay').value >0))?1:0; //1 if smoker (or quit within last year), 0 otherwise
	let systolic = SystolicPressure();
	let treated_bp = (HasHTN()) ? 1 : 0;
	let total_chol = parseFloat(document.getElementById("TCHLvalue").value);
	let hdl_chol = parseFloat(document.getElementById("HDLvalue").value);
	let predict_length = 10;
	let lipid_ratio = total_chol / hdl_chol;
	let risk = 0;
	let threshold = 10; //NICE suggested a threshold of 20%, now down to 10%
	let Diabetic = (HasDM()) ? 1 : 0;
	let IHD = (HasCAD()) ? 1 : 0;
	let CKD = (HasCKD()) ? 1 : 0;
	CHF = (HasCHF()) ? 1 : 0;
	cssString = 'text-align:left; color:red; background:white;';
	cssString2 = 'text-align:left; color:green; background:white;';
	theA1C = parseFloat(document.getElementById('A1Cvalue').value);
	estGFR = parseFloat(document.getElementById("eGFRvalue").value);
	Statin = (OnStatin()) ? 1 : 0;
	FramGender = (document.getElementById("PatientGender").value == 'M') ? "Male" : "Female";
	FramSmoking = ((document.getElementById('smoker').value == 'yes') || (document.getElementById('smoker').value == 'Yes') || (document.getElementById('dailySmokes').value > 0) || (document.getElementById('PacksPerDay').value > 0)) ? "Yes" : "No";
	FramTreatedBP = (HasHTN()) ? "Yes" : "No";
	FramDiabetic = (HasDM()) ? "Yes" : "No";
	FramIHD = (HasCAD()) ? "Yes" : "No";
	FramCKD = (HasCKD()) ? "Yes" : "No";
	FramSystolic = systolic;
	FramTC = total_chol;
	FramHDL = hdl_chol;
	AAPsychotic = (OnAAPsy()) ? 1 : 0;
	Accutane = (OnAccutane()) ? 1 : 0;

	if (($("#SmokingStatus").is(':checked') == true)) {
		smoking = 1;
		FramSmoking = 'Yes';
		//if ($("#smoker").val() != FramSmoking) {         //disables pushing to smoking status from Framinham
		//	$('#ReturnSmokingStatus').val(FramSmoking);
		//}
	}

	if (($("#SmokingStatus").is(':checked') == false)) {
		smoking = 0;
		FramSmoking = 'No';
	}

	if (($("#FamilyHistory").is(':checked') == true)) {
		familyHistoryCVD = 'Yes';
	}
	if (($("#FamilyHistory").is(':checked') == false)) {
		familyHistoryCVD = 'No';
	}

	if (age >= 20) {
		// no need to screen young adults at no identified risk: US Preventative Task Force Grade A
		if ((lipid_ratio) && (systolic)) {
			risk = Math.round(GetFraminghamCHDRiskPoints(age, sex, smoking, systolic, treated_bp, total_chol, hdl_chol) * 100);
			if ($("#FamilyHistory").is(':checked') == true) {
				risk = (Math.round(GetFraminghamCHDRiskPoints(age, sex, smoking, systolic, treated_bp, total_chol, hdl_chol) * 100) * 1.5);
			} else {
				risk = Math.round(GetFraminghamCHDRiskPoints(age, sex, smoking, systolic, treated_bp, total_chol, hdl_chol) * 100);
			}
			//risk = Math.round(Framingham1991(age, sex, smoking, systolic, lipid_ratio, predict_length)*100);
			let lipidDate = document.getElementById("TCHLdate").value;
			if ((lipidDate !== "") && (lipidDate != document.getElementById("m$FRAM#dateObserved").value) && (!(Diabetic)) && (!(IHD))) {
				document.getElementById("m$FRAM#dateObserved").value = lipidDate;
				document.getElementById("m$FRAM#value").value = risk;
				//add('subject', risk+"% Framingham risk");

			}
		} else {
			//stratify by risk calculated from existing data assuming average to poor bp and lipids
			if (!(systolic)) {
				systolic = 150;
				FramSystolic = "ESTIMATED 150";
			}
			//risk = Math.round(GetFraminghamCHDRiskPoints(age, sex, smoking, systolic, treated_bp, '6', '1')*100);
			risk = Math.round(Framingham1991(age, sex, smoking, systolic, '6', predict_length) * 100);
			if ($("#FamilyHistory").is(':checked') == true) {
				risk = (Math.round(Framingham1991(age, sex, smoking, systolic, '6', predict_length) * 100) * 1.5);
			} else {
				risk = Math.round(Framingham1991(age, sex, smoking, systolic, '6', predict_length) * 100);
			}
			FramTC = "ESTIMATED 6";
			FramHDL = "ESTIMATED 1";
		}

		if (Diabetic) {
			// UKPDS might be better but some argue that it underestimates risk
			risk = 30;  //this is above the threshold
		}

		if (IHD) {
			// the subject should be added only based on bloodwork being ordered, but no panel for this
			//add('subject','IHD ');
			risk = 30;  //this is above the threshold
		}

		if (CKD) {
			risk = 30;  //this is above the threshold
		}
	}

	//Risk score not done below 20yrs
	if ((age >= 0) && (age < 20)) {
		AddIfMissingTitle('LIPID1', "Patient is " + age + " yrs old. This CVD risk calculator is not valid below age 20yrs.\n");
		AddIfMissingTitle('LIPID1', "No need to screen young adults at no identified risk: US Preventative Task Force Grade A.\n");
		$('#lipidHeader').css('color', '#008000');
	}

	//Risk score range set for 20-74yrs
	if ((age >= 75) || (age < 20)) {
		AddIfMissingTitle('Framtitle', "This patient is " + age + "\nThe risk calculator is only useful between ages 20 and 75 yrs.");
		$("#Framtitle").css('color', 'black');
	}
	if ((age >= 20) && (age < 75)) {
		// populates Fram Score in side bar and changes color green blue red for low mod high risk ranges
		$("#Framrisk").val("~" + risk + "%");
		if (risk < 10) {
			$("#Framrisk").css('color', 'green');
			$("#Framtitle").css('color', 'green');
		}
		if ((risk >= 10) && (risk < 20)) {
			$("#Framrisk").css('color', 'blue');
			$("#Framtitle").css('color', 'blue');
		}
		if (risk >= 20) {
			$("#Framrisk").css('color', 'red');
			$("#Framtitle").css('color', 'red');
		}
		// Hover over Fram Score shows what was used to make the score
		StartAddIfMissingTitle('Framtitle', "CLICK to go to CVD Risk Calculator v2\n");
		AddIfMissingTitle('Framtitle', "Age:" + age + "\n");
		AddIfMissingTitle('Framtitle', "Sex:" + FramGender + "\n");
		AddIfMissingTitle('Framtitle', "Smoker:" + FramSmoking + "\n");
		AddIfMissingTitle('Framtitle', "Systolic pressure:" + FramSystolic + "\n");
		AddIfMissingTitle('Framtitle', "BP treated:" + FramTreatedBP + "\n");
		AddIfMissingTitle('Framtitle', "Total cholesterol:" + FramTC + "\n");
		AddIfMissingTitle('Framtitle', "HDL cholesterol:" + FramHDL + "\n");
		AddIfMissingTitle('Framtitle', "Diabetes:" + FramDiabetic + "\n");
		AddIfMissingTitle('Framtitle', "IHD:" + FramIHD + "\n");
		AddIfMissingTitle('Framtitle', "CKD:" + FramCKD + "\n");

		// Hover over smoker and family history
		AddIfMissingTitle('SmokingStatus', "Current smoker OR smoker within last 5yrs.");
		AddIfMissingTitle('FamilyHistory', "First degree family history of early CHD.\nMale < 55yrs or female < 65yrs.\nIncreases risk by 1.5.");

		if (risk < threshold) {
			//for patients at low risk a single cholesterol is recommended for males >40 and females >50.This form allows for a cholesterol done within 5yrs of that age.
			StartAddIfMissingTitle('LIPID1', "At low ~" + risk + "% 10yr cardiac risk. ");
			$('#lipidHeader').css('color', '#008000');
			if ((sex == 1) && (age >= 50) && (getLabAge('TCHLdate') <= ((age - 49) * 12))) {
				AddIfMissingTitle('LIPID1', "\nThis female patient has had a lipid screening profile at " + (age - (Math.round((getLabAge('TCHLdate')) / 12))) + " yrs of age fulfills the recommendations of a single lipid profile screen around 50yrs.\nThere is no need for further lipid screening unless her medical condition changes or if you are considering low risk primary prevention with a statin drug\nLow risk primary prevention with a statin is not generally recommended.");
			}
			if ((sex == 0) && (age >= 40) && (getLabAge('TCHLdate') <= ((age - 39) * 12))) {
				AddIfMissingTitle('LIPID1', "\nThis male patient has had a lipid screening profile at " + (age - (Math.round((getLabAge('TCHLdate')) / 12))) + " yrs of age which fulfills the recommendations of a single lipid profile screen around 40yrs.\nThere is no need for further lipid screening unless his medical condition changes or if you are considering low risk primary prevention with a statin drug\nLow risk primary prevention with a statin is not generally recommended.");
			}

			if (((sex == 1) && (age >= 50)) || ((sex == 0) && (age >= 40))) {
				if (((getLabAge('TCHLdate') > ((age - 39) * 12)) && (sex == 0)) || ((getLabAge('TCHLdate') > ((age - 49) * 12)) && (sex == 1))) {
					AddIfMissingTitle('LIPID1', "\nPatient is " + age + " yrs old.\nFor low risk males >40yrs and females >50yrs a single screening lipid profile is recommended.\nThis does not need to be repeated unless the patients risks change.");
					$('#lipidHeader').css('color', '#ff0000');
					$("#Lipid_full").addClass('yellow');
				}
			}

			if (((sex == 1) && (age < 50)) || ((sex == 0) && (age < 40))) {
				if (getLabAge('TCHLdate') != 1200) {
					AddIfMissingTitle('LIPID1', "\nA lipid profile was done at " + (age - (Math.round((getLabAge('TCHLdate')) / 12))) + " yrs of age.\nPatient is " + age + "yrs old.\nFor low risk patients a single screening lipid profile is recommended for males at age 40yrs and females at age 50yrs.");
				}
				if (getLabAge('TCHLdate') == 1200) {
					AddIfMissingTitle('LIPID1', "\nPatient is " + age + "yrs old.\nFor low risk patients a single screening lipid profile is recommended for males at age 40yrs and females at age 50yrs.");
				}
			}
		}
		if ((risk >= threshold) && (Statin == 0) && (age >= 20) && (age < 40) && (sex == 0)) {
			//More aggressive and frequent determinations are indicated for those at higher risk. Initially every 5yrs. No lipid monitoring if on statin.
			StartAddIfMissingTitle('LIPID1', "At ~" + risk + "% 10yr cardiac risk. ");
			AddIfMissingTitle('LIPID1', "\nPatient is " + age + " yrs old.\nFor males less than 40yrs at higher CVD risk that are not considering a statin for primary prevention at this time, it would be reasonable to do lipid profiles every 5yrs. ");
			if (getLabAge('TCHLdate') > 60) {
				//red it
				AddIfMissingTitle('LIPID1', "\nThere is no charted cholesterol in the last 5 years so consider repeating a lipid profile. ");
				$('#lipidHeader').css('color', '#ff0000');
				$("#Lipid_full").addClass('yellow');
			} else {
				//green it
				AddIfMissingTitle('LIPID1', "Recent cholesterol done " + Math.round(getLabAge('TCHLdate') / 12) + " years ago. ");
				$('#lipidHeader').css('color', '#008000');
			}
		}
		if ((risk >= threshold) && (Statin == 0) && (age >= 20) && (age < 50) && (sex == 1)) {
			//More aggressive and frequent determinations are indicated for those at higher risk. Initially every 5yrs.No lipid monitoring if on statin.
			StartAddIfMissingTitle('LIPID1', "At ~" + risk + "% 10yr cardiac risk. ");
			AddIfMissingTitle('LIPID1', "\nPatient is " + age + " yrs old.\nFor females less than 50yrs at higher CVD risk that are not considering a statin for primary prevention at this time, it would be reasonable to do lipid profiles every 5yrs. ");
			if (getLabAge('TCHLdate') > 60) {
				//red it
				AddIfMissingTitle('LIPID1', "\nThere is no charted cholesterol in the last 5 years so consider repeating a lipid profile. ");
				$('#lipidHeader').css('color', '#ff0000');
				$("#Lipid_full").addClass('yellow');
			} else {
				//green it
				AddIfMissingTitle('LIPID1', "Recent cholesterol done " + Math.round(getLabAge('TCHLdate') / 12) + " years ago. ");
				$('#lipidHeader').css('color', '#008000');
			}
		}
		if ((risk >= threshold) && (Statin == 0) && (age >= 50) && (sex == 1)) {
			//Increase monitoring to Q2yrs for high risk males >40 and females >50. No lipid monitoring if on statin.
			StartAddIfMissingTitle('LIPID1', "At ~" + risk + "% 10yr cardiac risk. ");
			AddIfMissingTitle('LIPID1', "\nPatient is " + age + " yrs old.\nFor females older than 50yrs at higher CVD risk that are not considering a statin for primary prevention at this time, it would be reasonable to do lipid profiles every 2yrs. ");
			if (getLabAge('TCHLdate') > 24) {
				//red it
				AddIfMissingTitle('LIPID1', "No charted cholesterol in the last 2 years. ");
				$('#lipidHeader').css('color', '#ff0000');
				$("#Lipid_full").addClass('yellow');
			} else {
				//green it
				AddIfMissingTitle('LIPID1', "\nRecent cholesterol done " + Math.round(getLabAge('TCHLdate') / 12) + " years ago. ");
				$('#lipidHeader').css('color', '#008000');
			}
		}

		if ((risk >= threshold) && (Statin == 0) && (age >= 40) && (sex == 0)) {
			//Increase monitoring to Q2yrs for high risk males >40 and females >50. No lipid monitoring if on statin.
			StartAddIfMissingTitle('LIPID1', "At ~" + risk + "% 10yr cardiac risk. ");
			AddIfMissingTitle('LIPID1', "\nPatient is " + age + " yrs old.\nFor males older than 40yrs at higher CVD risk that are not considering a statin for primary prevention at this time, it would be reasonable to do lipid profiles every 2yrs. ");
			if (getLabAge('TCHLdate') > 24) {
				//red it
				AddIfMissingTitle('LIPID1', "No charted cholesterol in the last 2 years. ");
				$('#lipidHeader').css('color', '#ff0000');
				$("#Lipid_full").addClass('yellow');
			} else {
				//green it
				AddIfMissingTitle('LIPID1', "\nRecent cholesterol done " + Math.round(getLabAge('TCHLdate') / 12) + " years ago. ");
				$('#lipidHeader').css('color', '#008000');
			}
		}

		if ((Statin === 0) && (age >= 20) && (AAPsychotic === 1)) {
			//Do lipid profiles biannually for AApsychotics.No lipid monitoring reasonable if on statin.
			StartAddIfMissingTitle('LIPID1', "At ~" + risk + "% 10yr cardiac risk. ");
			AddIfMissingTitle('LIPID1', "\nPatient is " + age + " yrs old and is on an atypical antipsychotic. Biannual lipid profiles are reasonable. ");
			if (getLabAge('TCHLdate') > 23) {
				//red it
				AddIfMissingTitle('LIPID1', "\nThere is no charted cholesterol in the last 2 years so consider repeating a lipid profile. ");
				$('#lipidHeader').css('color', '#ff0000');
				$("#Lipid_full").addClass('yellow');
			} else {
				//green it
				AddIfMissingTitle('LIPID1', "\nRecent cholesterol done " + getLabAge('TCHLdate') + " months ago. ");
				$('#lipidHeader').css('color', '#008000');
			}
		}
		if ((Statin === 0) && (age >= 20) && (CKD === 1)) {
			//Do lipid profiles biannually for CKD.No lipid monitoring reasonable if on statin.
			StartAddIfMissingTitle('LIPID1', "At ~" + risk + "% 10yr cardiac risk. ");
			AddIfMissingTitle('LIPID1', "\nPatient is " + age + " yrs old and has CKD. Biannual lipid profiles are reasonable. ");
			if (getLabAge('TCHLdate') > 23) {
				//red it
				AddIfMissingTitle('LIPID1', "\nThere is no charted cholesterol in the last 2 years so consider repeating a lipid profile. ");
				$('#lipidHeader').css('color', '#ff0000');
				$("#Lipid_full").addClass('yellow');
			} else {
				//green it
				AddIfMissingTitle('LIPID1', "\nRecent cholesterol done " + getLabAge('TCHLdate') + " months ago. ");
				$('#lipidHeader').css('color', '#008000');
			}
		}
		if ((Statin === 0) && (age >= 20) && (Diabetic === 1)) {
			//Do lipid profiles annually for diabetics.No lipid monitoring reasonable if on statin.
			StartAddIfMissingTitle('LIPID1', "At ~" + risk + "% 10yr cardiac risk. ");
			AddIfMissingTitle('LIPID1', "\nPatient is " + age + " yrs old and has diabetes and is not on a statin. Annual lipid profiles are recommended. ");
			if (getLabAge('TCHLdate') > 11) {
				//red it
				AddIfMissingTitle('LIPID1', "\nThere is no charted cholesterol in the last year so consider repeating a lipid profile. ");
				$('#lipidHeader').css('color', '#ff0000');
				$("#Lipid_full").addClass('yellow');
			} else {
				//green it
				AddIfMissingTitle('LIPID1', "\nRecent cholesterol done " + getLabAge('TCHLdate') + " months ago. ");
				$('#lipidHeader').css('color', '#008000');
			}
		}
		if ((Statin === 0) && (age >= 20) && (Accutane === 1)) {
			//Do lipid profiles monthly on accutane.No lipid monitoring reasonable if on statin.
			StartAddIfMissingTitle('LIPID1', "At ~" + risk + "% 10yr cardiac risk. ");
			AddIfMissingTitle('LIPID1', "\nPatient is " + age + " yrs old and is on accutane. Monthly lipid profiles are recommended. ");
			if (getLabAge('TCHLdate') > 1) {
				//red it
				AddIfMissingTitle('LIPID1', "\nThere is no charted cholesterol in the last month so consider repeating a lipid profile. ");
				$('#lipidHeader').css('color', '#ff0000');
				$("#Lipid_full").addClass('yellow');
			} else {
				//green it
				AddIfMissingTitle('LIPID1', "\nRecent cholesterol done " + getLabAge('TCHLdate') + " months ago. ");
				$('#lipidHeader').css('color', '#008000');
			}
		}

		if ((risk >= threshold) && (Statin === 1)) {
			//No lipid monitoring if on statin.
			StartAddIfMissingTitle('LIPID1', "At ~" + risk + "% 10yr cardiac risk.\n ");
			AddIfMissingTitle('LIPID1', "Patient is on a statin drug.\n There is a move towards titrating the statin dose and ignoring the LDL level, so reasonable to not repeat lipid profile ");
			$('#lipidHeader').css('color', '#008000');
		}
	}

	if (age >= 75) {
		StartAddIfMissingTitle('LIPID1', "Patient is " + age + " yrs old. ");
		AddIfMissingTitle('LIPID1', "Risk is elevated in the elderly, but there is little evidence for statins in PRIMARY PREVENTION over age 75yrs. ");
		AddIfMissingTitle('LIPID1', "\nTreatment may be beneficial (ARR 0.5-2% SAGE PROSPER) for those older than 75yrs with established disease or with risk factors such as smoking or hypertension. ");
		AddIfMissingTitle('SmokingStatus', "Current smoker OR smoker within last 5yrs.");
		AddIfMissingTitle('FamilyHistory', "First degree family history of early CHD.\nMale < 55yrs or female < 65yrs.\nIncreases risk by 1.5.");
	}

	/*
	 * Who gets to maintain this price list??
	 */
	$("#HematologyProfile").attr('title', 'Cost: $10,96-$28,95');
	$("#PTINR").attr('title', 'Cost: $12,07');
	$("#Ferritin").attr('title', 'Cost: $10,12');
	$("#A1c").attr('title', 'Cost: $12,69');
	$("#ACR").attr('title', 'Cost: $11,41');
	$("#MonitorThyroidRx").attr('title', 'Cost: $9,90');
	$("#TSH").attr('title', 'Cost: $9,90 + $12,12 = $22,02');
	$("#Sodium").attr('title', 'Cost: $1.38');
	$("#Potassium").attr('title', 'Cost: $1.39');
	$("#CreatinineGFR").attr('title', 'Cost: $1.52');
	$("#Lipid_full").attr('title', 'Cost: $21,31');
	$("#Lipid_FU").attr('title', 'Cost: $14,44');
	$("#Lipid_ApoB").attr('title', 'Cost: $16,60');
	// $("#LipidProfileNon-MSP").attr('title', 'Cost: $21,31');
	$("#SuspectHyperthyroidism").attr('title', 'Cost: $9,90 + $12,12 + 12,12 = $34,14');
	$("#GlucoseFasting").attr('title', 'Cost: $1.46');
	$("#GlucoseRandom").attr('title', 'Cost: $1.46');
	$("#GTTGDMScreen").attr('title', 'Cost: $10,03');
	$("#GTTGDMConfirmation").attr('title', 'Cost: $15,84');
	$("#Albumin").attr('title', 'Cost: $1,55');
	$("#AlkPhos").attr('title', 'Cost: $1,57');
	$("#ALT").attr('title', 'Cost: $1,47');
	$("#Bilirubin").attr('title', 'Cost: $1,61');
	$("#GGT").attr('title', 'Cost: $1,66');
	$("#TProtein").attr('title', 'Cost: $1,60');
	$("#Calcium").attr('title', 'Cost: $1.55');
	$("#CreatineKinase").attr('title', 'Cost: $1,88');
	$("#PSAbillMSP_Yes").attr('title', 'Cost: $14,35');
	$("#PSAbillMSP_No").attr('title', 'Cost: $14,35');
	$("#bHCG").attr('title', 'Cost: $16,30');
	$("#PregnancyTest").attr('title', 'Cost: $15,30');
	$("#UrineCulture").attr('title', 'Cost: $19.57 + $9.55/org + $11.61/Ab Sus');
	$("#UrineMicroscopicOnly").attr('title', 'Cost: $7.17');
	$("#UrineMacroscopicOnly").attr('title', 'Cost: $7.42');
	$("#UrineMacroscopicMicroscopicIfDipstickPositive").attr('title', 'Cost: $14.59');
	$("#UrineMacroscopicCultureIfPyuriaOrNitrate").attr('title', 'Cost: $26.99 + $9.55/org + $11.61/Ab Sus');
	$("#ECG").attr('title', 'Cost: $32.47');
	$("#Holter").attr('title', 'Cost: $89.19');
	$("#FIT_CSP").attr('title', 'Cost: $19.60');
	$("#FIT_Other").attr('title', 'Cost: $19.60');
	$("#B12").attr('title', 'Cost: $14.38');
	$("#CRPC").attr('title', 'Cost: $10.31');
	$("#ESRC").attr('title', 'Cost: $10.61');
	$("#VaginoAnoRectalGBS").attr('title', 'Cost: $15.40');
	$("#ChlamydiaGC").attr('title', 'Cost: $29.94');
	$("#CDToxin").attr('title', 'Cost: $16.64');
	$("#StoolCS").attr('title', 'Cost: $16.90 + $14.42/org');
	$("#StoolOP").attr('title', 'Cost: $46.93');
	$("#StoolOPHighRisk").attr('title', 'Cost: $93.86');
	$("#DermatophyteCulture").attr('title', 'Cost: $21.41');
	$("#FungusKOHPrep").attr('title', 'Cost: $13.76');
	$("#HBsAg").attr('title', 'Cost: $10.40');
	$("#URICC").attr('title', 'Cost: $1.70');
	$("#DIGC").attr('title', 'Cost: $18.97');
	$("#DILC").attr('title', 'Cost: $17.13');
	$("#LITHC").attr('title', 'Cost: $14.94');
	$("#CEAC").attr('title', 'Cost: $20.40');
	$("#AFPC").attr('title', 'Cost: $24.79');
	$("#ANAC").attr('title', 'Cost: $23.82 + $74.64/Ab');
	$("#RFC").attr('title', 'Cost: $8.41');
	$("#ASTC").attr('title', 'Cost: $1.73');
	$("#AcuteViralHepatitis").attr('title', 'Cost: $36.12');
	$("#ChronicViralHepatitis").attr('title', 'Cost: $47.26');
	$("#HepatitisAImmuneStatus").attr('title', 'Cost: $18.42');
	$("#HepatitisBImmuneStatus").attr('title', 'Cost: $11.08');
	$("#HIVNominal").attr('title', 'Cost: ?$10.00');
	$("#HIVNonNominal").attr('title', 'Cost: ?$10.00');
	$("#Throat").attr('title', 'Cost: $18.75 - 27.73');
	$("#SuperficialWound").attr('title', 'Cost: $52.79 - 62.34');
	$("#DeepWound").attr('title', 'Cost: $52.79 - 62.34');
	$("#VaginitisInitial").attr('title', 'Cost: $38.92 - 48.80');
	$("#VaginitisChronic").attr('title', 'Cost: $24.35');
	$("#Trichomonas").attr('title', 'Cost: $11.63 - 18.75');
	$("#GCOnly").attr('title', 'Cost: $28.85 - 29.94');
	$("#YeastCulture").attr('title', 'Cost: $23.52');
	$("#FungusCulture").attr('title', 'Cost: $13.76 - 47.67');
	$("#CCPC").attr('title', 'Cost: $55 if private');
	$("#TTGC").attr('title', 'Cost: $13.92');
	$("#A1ATC").attr('title', 'Cost: $20.06');
	$("#TGbC").attr('title', 'Cost: $27.90');
	$("#BNPC").attr('title', 'Cost: $28.14');
	$("#VitDC").attr('title', 'Cost: $94.49');

	setInterval(function calculateCost() {
		$('#Costs').val(0);
		StartAddIfMissingTitle('Costs', "");

		let othertests = $('#AdditionalTestInstructions').val();
		let OtherTests = othertests.toUpperCase();
		let match = OtherTests.search("AST|PHOSPHATE|PO4|URIC|LDH|LACTATE DEHYDROGENASE");

		if ((match !== -1) || (($('#Sodium').val() === 'X') || ($('#Potassium').val() === 'X') || ($('#CreatinineGFR').val() === 'X') || ($('#Albumin').val() === 'X') || ($('#AlkPhos').val() === 'X') || ($('#ALT').val() === 'X') || ($('#Bilirubin').val() === 'X') || ($('#GGT').val() === 'X') || ($('#TProtein').val() === 'X') || ($('#Calcium').val() === 'X') || ($('#CreatineKinase').val() === 'X') || ($('#GlucoseRandom').val() === 'X') || ($('#GlucoseFasting').val() === 'X'))) {
			newcost = Math.round(($('#Costs').val() * 1) + 15.62);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Base Chemistry Fee: $15.62\n");
		}

		if ($('#Sodium').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 1.39);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Na: $1.39\n");
		}
		if ($('#Potassium').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 1.38);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "K: $1.38\n");
		}
		if ($('#CreatinineGFR').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 1.52);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "eGFR: $1.52\n");
		}
		if ($('#Albumin').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 1.55);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Alb: $1.55\n");
		}
		if ($('#AlkPhos').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 1.57);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "ALP: $1.57\n");
		}
		if ($('#ALT').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 1.47);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "ALT: $1.47\n");
		}
		if ($('#Bilirubin').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 1.61);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "BILI: $1.61\n");
		}
		if ($('#GGT').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 1.66);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "GGT: $1.66\n");
		}
		if ($('#TProtein').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 1.60);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "TProtein: $1.60\n");
		}
		if ($('#Calcium').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 1.55);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Ca: $1.55\n");
		}
		if ($('#CreatineKinase').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 1.88);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "CK: $1.88\n");
		}
		if ($('#HematologyProfile').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 10.96);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "CBC: $10.96\n");
		}
		if ($('#PTINR').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 12.07);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "INR: $12.07\n");
		}
		if ($('#Ferritin').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 10.12);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Ferritin: $10.12\n");
		}
		if ($('#GlucoseFasting').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 1.46);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "FBS: $1.46\n");
		}
		if ($('#GlucoseRandom').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 1.46);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "RBS: $1.46\n");
		}
		if ($('#GTTGDMScreen').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 10.03);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "50G GTT: $10.03\n");
		}
		if ($('#GTTGDMConfirmation').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 15.84);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "75G GTT: $15.84\n");
		}
		if ($('#A1c').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 12.69);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "A1C: $12.69\n");
		}
		if ($('#ACR').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 11.41);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "ACR: $11.41\n");
		}
		if ($('#Lipid_full').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 21.31);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "LipidProfile: $21.31\n");
		}
		if ($('#Lipid_FU').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 14.44);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "LipidFU: $14.44\n");
		}
		if ($('#Lipid_ApoB').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 16.60);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "ApoB: $16.60\n");
		}

		if ($('#MonitorThyroidRx').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 9.90);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "TSH: $9.90\n");
		}
		if ($('#TSH').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 22.02);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "TSH/T4: $22.02\n");
		}
		if ($('#SuspectHyperthyroidism').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 34.14);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "TSH/T4/T3: $34.14\n");
		}
		if ($('#PSAbillMSP_Yes').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 14.35);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "PSA: $14.35\n");
		}
		if ($('#PSAbillMSP_No').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 14.35);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "PSA: $14.35\n");
		}
		if ($('#bHCG').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 16.30);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "SerumPregTest: $16.30\n");
		}
		if ($('#PregnancyTest').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 15.30);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "UrinePregTest: $15.30\n");
		}
		if (($('#FIT_CSP').val() === 'X') || ($('#FIT_Other').val() === 'X')) {
			newcost = Math.round(($('#Costs').val() * 1) + 19.60);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "FIT: $19.60\n");
		}
		if ($('#ECG').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 32.47);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "ECG: $32.47\n");
		}
		if ($('#Holter').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 89.19);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "ECG: $89.19\n");
		}
		if ($('#UrineCulture').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 40.73);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "UrineCulture: $40.73 ($19.57 + $9.55/org + $11.61/Ab Sus)\n");
		}
		if ($('#UrineMacroscopicMicroscopicIfDipstickPositive').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 14.59);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "UrineMacroMicro: $14.59\n");
		}
		if ($('#UrineMacroscopicCultureIfPyuriaOrNitrate').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 48.15);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "UrineMacroCulture: $48.15 ($26.99 + $9.55/org + $11.61/Ab Sus)\n");
		}
		if ($('#UrineMacroscopicOnly').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 7.42);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "UrineMacro: $7.42\n");
		}
		if ($('#UrineMicroscopicOnly').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 7.17);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "UrineMicro: $7.17\n");
		}
		if ($('#VaginoAnoRectalGBS').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 15.40);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "GBS: $15.40\n");
		}
		if ($('#ChlamydiaGC').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 29.94);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "ChlGC: $29.94\n");
		}
		if ($('#StoolCS').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 16.90);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Stool Culture: $16.90 + $14.42/org\n");
		}
		if ($('#CDToxin').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 16.64);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "CDiff: $16.64\n");
		}
		if ($('#StoolOP').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 46.93);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "StoolOP: $46.93\n");
		}
		if ($('#StoolOPHighRisk').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 93.86);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "StoolOPX2: $93.86\n");
		}
		if ($('#DermatophyteCulture').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 21.41);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Dermatophyte Culture: $21.41\n");
		}
		if ($('#FungusKOHPrep').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 13.76);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Fungal KOH: $13.76\n");
		}
		if ($('#HBsAg').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 10.40);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "HBsAg: $10.40\n");
		}
		if ($('#AcuteViralHepatitis').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 36.12);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Acute hepatitis: $36.12\n");
		}
		if ($('#ChronicViralHepatitis').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 47.20);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Chronic hepatitis: $47.20\n");
		}
		if ($('#HepatitisAImmuneStatus').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 18.42);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "HepA status: $18.42\n");
		}
		if ($('#HepatitisBImmuneStatus').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 11.08);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "HepB Status: $11.08\n");
		}
		if (($('#HIVNominal').val() === 'X') || ($('#HIVNonNominal').val() === 'X')) {
			newcost = Math.round(($('#Costs').val() * 1) + 10.00);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "HIV: ?$10.00\n");
		}
		if ($('#Throat').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 22.96);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Throat Swab: $22,96 ($18.18-27.23)\n");
		}
		if ($('#SuperficialWound').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 57.57);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Sup Wound Cult: $57.57 ($52.79-62.34)\n");
		}
		if ($('#DeepWound').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 57.57);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Deep Wound Cult: $57.57 ($52.79-62.34)\n");
		}
		if ($('#VaginitisInitial').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 43.86);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "BV+Candida: $43.86 ($38.92-48.80)\n");
		}
		if ($('#VaginitisChronic').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 24.35);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Vaginitis Chronic: $24.35 ($18.75-29.94)\n");
		}
		if ($('#Trichomonas').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 15.19);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Trichomonas: $15.19 ($11.63-18.75)\n");
		}
		if ($('#GCOnly').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 28.85);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "GC: $28.85\n");
		}
		if ($('#YeastCulture').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 23.52);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Yeast: $23.52\n");
		}
		if ($('#FungusCulture').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 30.72);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Fungus: $30.72 ($13.76-47.67)\n");
		}

		if ($('#B12').val() === 'X') {
			newcost = Math.round(($('#Costs').val() * 1) + 14.38);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "B12: $14.38\n");
		}

		match = OtherTests.search("ESR");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 10.61);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "ESR: $10.61\n");
		}
		match = OtherTests.search("CRP");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 10.31);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "CRP: $10.31\n");
		}
		match = OtherTests.search("TTG");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 13.92);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "TTG: $13.92\n");
		}
		match = OtherTests.search("HP BREATH");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 36.50);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "HPBreathTest: $36.50\n");
		}
		match = OtherTests.search("URIC");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 1.70);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Uric: $1.70\n");
		}
		match = OtherTests.search("DIG");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 18.97);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Digoxin: $18.97\n");
		}
		match = OtherTests.search("DILANT");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 17.13);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Dilantin: $17.13\n");
		}
		match = OtherTests.search("LITHIUM");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 14.94);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Lithium: $14.94\n");
		}
		match = OtherTests.search("MG|MAGNESIUM");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 6.79);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Mg: $6.79\n");
		}
		match = OtherTests.search("CA125");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 22.72);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "CA125: $22.72\n");
		}
		match = OtherTests.search("CA19-9");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 20.88);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "CA19-9: $20.88\n");
		}
		match = OtherTests.search("CA15-3");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 21.25);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "CA15-3: $21.25\n");
		}
		match = OtherTests.search("FSH");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 13.13);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "FSH: $13.13\n");
		}
		match = OtherTests.search("LH");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 12.41);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "LH: $12.41\n");
		}
		match = OtherTests.search("PROLACTIN");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 13.49);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Prolactin: $13.49\n");
		}
		match = OtherTests.search("BLOOD GROUP");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 16.09);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Blood Group: $16.09\n");
		}
		match = OtherTests.search("RH");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 10.38);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Rh: $10.38\n");
		}
		match = OtherTests.search("IPTH");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 17.52);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "iPTH: $17.52\n");
		}
		match = OtherTests.search("ENA");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 30.60);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "ENA: $30.60\n");
		}
		match = OtherTests.search("FACTOR 5");
		let match2 = OtherTests.search("FACTOR V");
		if ((match !== -1) || (match2 !== -1)) {
			newcost = Math.round(($('#Costs').val() * 1) + 52.04);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Factor 5 Leiden: $52.04\n");
		}
		match = OtherTests.search("PROTEIN C");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 51.33);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Protein C: $51.33\n");
		}
		match = OtherTests.search("PROTEIN S");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 38.31);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "PROTEIN S: $38.31\n");
		}
		match = OtherTests.search("ANTITHROMBIN");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 33.49);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Antithrombin 3: $33.49\n");
		}
		match = OtherTests.search("MONOSPOT");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 17.10);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Monospot: $17.10\n");
		}
		match = OtherTests.search("CERULOPLASM");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 10.15);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Ceruloplasmin: $10.15\n");
		}
		match = OtherTests.search("COPPER");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 49.19);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Copper: $49.19\n");
		}
		match = OtherTests.search("SERUM PROTEIN EL");
		match2 = OtherTests.search("SPEP");
		if ((match !== -1) || (match2 !== -1)) {
			newcost = Math.round(($('#Costs').val() * 1) + 26.54);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "SPEP: $26.54\n");
		}
		match = OtherTests.search("TROPONIN");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 15.05);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Troponin: $15.05\n");
		}
		match = OtherTests.search("SEMEN");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 82.34);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Semenanalysis: $82.34\n");
		}
		match = OtherTests.search("VITAMIN D");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 61.32);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Vit D: $61.32\n");
		}
		match = OtherTests.search("HBEAG");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 14.87);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "HBeAg: $14.87\n");
		}
		match = OtherTests.search("ANTI-HBEAG");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 15.00);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Anti-HBeAg: $15.00\n");
		}
		match = OtherTests.search("HBV DNA");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 60.34);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "HBV DNA: $60.34\n");
		}
		match = OtherTests.search("DRVVT");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 14.01);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "DRVVT: $14.01\n");
		}
		match = OtherTests.search("BNP");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 28.14);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "BNP: $28.14\n");
		}
		match = OtherTests.search("PHOSPHATE");
		match2 = OtherTests.search("PO4");
		if ((match !== -1) || (match2 !== -1)) {
			newcost = Math.round(($('#Costs').val() * 1) + 1.64);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "PO4: $1.64\n");
		}
		match = OtherTests.search("TESTOSTERONE");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 15.81);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Testosterone: $15.81\n");
		}
		match = OtherTests.search("URINARY CALCIUM");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 5.48);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Urine Calcium: $5.48\n");
		}
		match = OtherTests.search("DHEA");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 18.55);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "DHEAS: $18.55\n");
		}
		match = OtherTests.search("VDRL");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 15.96);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "VDRL: $15.96\n");
		}
		match = OtherTests.search("ESTRADIOL");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 22.43);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Estradiol: $22.43\n");
		}
		match = OtherTests.search("AFP");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 24.79);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "AFP: $24.79\n");
		}
		match = OtherTests.search("CEA");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 20.40);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "CEA: $20.40\n");
		}
		match = OtherTests.search("RF");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 8.41);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "RF: $8.41\n");
		}
		match = OtherTests.search("ANA");
		match2 = OtherTests.search("ANALYSIS");
		if ((match !== -1) && (match2 == -1)) {
			newcost = Math.round(($('#Costs').val() * 1) + 23.82);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "ANA: $23.82(base+$75 per autoAb)\n");
		}
		match = OtherTests.search("HEP C|HCV");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 10.00);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Hep C: ?$10.00\n");
		}
		match = OtherTests.search("RUBELLA");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 10.00);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Rubella: ?$10.00\n");
		}
		match = OtherTests.search("VZ");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 10.00);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "VZ IgG: ?$10.00\n");
		}
		match = OtherTests.search("RPR|SYPHILIS");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 10.00);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "RPR: ?$10.00\n");
		}
		match = OtherTests.search("ANTITRYPSIN|A1AT");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 20.06);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Alpha-1 antitrypsin: $20.06\n");
		}
		match = OtherTests.search("MITOCHONDRIAL");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 23.82);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "Anti-mitochondrial AB: $23.82 + $27.03/Extra Ab\n");
		}
		match = OtherTests.search("LDH|LACTATE DEHYDROGENASE");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 1.62);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "LDH: $1.62\n");
		}
		match = OtherTests.search("DDIMER|D DIMER|D-DIMER");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 23.27);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "D-dimer: $23.27\n");
		}
		match = OtherTests.search("CCP");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 55);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "CCP: $55.00\n");
		}
		match = OtherTests.search("THYROGLOBULIN");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 27.90);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "THYROGLOBULIN: $27.90\n");
		}
		match = OtherTests.search("VITAMIN D");
		if (match !== -1) {
			newcost = Math.round(($('#Costs').val() * 1) + 94.49);
			$('#Costs').val(newcost);
			AddIfMissingTitle('Costs', "THYROGLOBULIN: $94.49\n");
		}


		match = OtherTests.search("ANA");
		match2 = OtherTests.search("ANALYSIS");
		let dateANA = $('#ANADate').val();
		let valueANA = $('#ANAVal').val();
		if ((match !== -1) && (match2 == -1) && ($('#ANADate').val() !== "")) {
			AddIfMissingTitle('PrintSubmitButton', "ANA was done " + dateANA + " ago. Result: " + valueANA + " .\nGenerally one does not need to repeat unless there is a change in clinical status or if another diagnosis is considered.\n");
			$("#PrintSubmitButton").addClass('warning');
		}

		match = OtherTests.search("RF");
		let dateRF = $('#RFDate').val();
		let valueRF = $('#RFVal').val();
		if ((match !== -1) && ($('#RFDate').val() !== "")) {
			AddIfMissingTitle('PrintSubmitButton', "RF was done " + dateRF + " ago. Result: " + valueRF + " .\nGenerally one does not need to repeat unless there is a change in clinical status or if another diagnosis is considered.\n");
			$("#PrintSubmitButton").addClass('warning');
		}

		match = OtherTests.search("TTG");
		let dateTTG = $('#TTGDate').val();
		let valueTTG = $('#TTGVal').val();
		if ((match !== -1) && ($('#TTGDate').val() !== "")) {
			AddIfMissingTitle('PrintSubmitButton', "TTG was done " + dateTTG + " ago. Result: " + valueTTG + " .\nGenerally one does not need to repeat unless it is used to monitor a known patient with celiac disease.\n");
			$("#PrintSubmitButton").addClass('warning');
		}
	}, 1000);
}